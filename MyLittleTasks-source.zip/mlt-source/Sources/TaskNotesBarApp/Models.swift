import Foundation

struct TaskItem: Identifiable, Codable, Equatable {
    let id: UUID
    var title: String
    var category: String?
    var parentTaskID: UUID?
    var isCompleted: Bool
    let createdAt: Date

    init(
        id: UUID = UUID(),
        title: String,
        category: String? = nil,
        parentTaskID: UUID? = nil,
        isCompleted: Bool = false,
        createdAt: Date = .now
    ) {
        self.id = id
        self.title = title
        self.category = category
        self.parentTaskID = parentTaskID
        self.isCompleted = isCompleted
        self.createdAt = createdAt
    }
}

struct AppCategory: Identifiable, Codable, Equatable {
    let id: UUID
    var name: String
    var iconSystemName: String
    var iconEmoji: String?
    var iconFilePath: String?

    init(
        id: UUID = UUID(),
        name: String,
        iconSystemName: String = "checklist.checked",
        iconEmoji: String? = nil,
        iconFilePath: String? = nil
    ) {
        self.id = id
        self.name = name
        self.iconSystemName = iconSystemName
        self.iconEmoji = iconEmoji
        self.iconFilePath = iconFilePath
    }
}

enum AppTintStyle: String, Codable, CaseIterable, Identifiable {
    case graphite
    case blue
    case green
    case amber
    case rose
    case custom

    var id: String { rawValue }
}

enum AutoBackupFrequency: String, Codable, CaseIterable, Identifiable {
    case off
    case daily
    case weekly
    case monthly

    var id: String { rawValue }

    var title: String {
        switch self {
        case .off: return "Off"
        case .daily: return "Daily"
        case .weekly: return "Weekly"
        case .monthly: return "Monthly"
        }
    }
}

enum CalendarNewEventTarget: String, Codable, CaseIterable, Identifiable {
    case apple
    case google
    case outlook

    var id: String { rawValue }

    var title: String {
        switch self {
        case .apple: return "Apple Calendar"
        case .google: return "Google Calendar"
        case .outlook: return "Outlook"
        }
    }
}

struct AppPreferences: Codable, Equatable {
    var menuBarIconSystemName: String = "checklist.checked"
    var tintStyle: AppTintStyle = .blue
    var customTintHex: String? = nil
    var launchAtLogin: Bool = false
    var marqueeLongTaskTitles: Bool = true
    var autoBackupFrequency: AutoBackupFrequency = .off
    var lastAutoBackupAt: Date? = nil
    var calendarNewEventTarget: CalendarNewEventTarget = .apple
    var showPinnedTaskInMenuBar: Bool = false
    var pinnedMenuBarTaskID: UUID? = nil

    init() {}

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        menuBarIconSystemName = try container.decodeIfPresent(String.self, forKey: .menuBarIconSystemName) ?? "checklist.checked"
        tintStyle = try container.decodeIfPresent(AppTintStyle.self, forKey: .tintStyle) ?? .blue
        customTintHex = try container.decodeIfPresent(String.self, forKey: .customTintHex)
        launchAtLogin = try container.decodeIfPresent(Bool.self, forKey: .launchAtLogin) ?? false
        marqueeLongTaskTitles = try container.decodeIfPresent(Bool.self, forKey: .marqueeLongTaskTitles) ?? true
        autoBackupFrequency = try container.decodeIfPresent(AutoBackupFrequency.self, forKey: .autoBackupFrequency) ?? .off
        lastAutoBackupAt = try container.decodeIfPresent(Date.self, forKey: .lastAutoBackupAt)
        calendarNewEventTarget = try container.decodeIfPresent(CalendarNewEventTarget.self, forKey: .calendarNewEventTarget) ?? .apple
        showPinnedTaskInMenuBar = try container.decodeIfPresent(Bool.self, forKey: .showPinnedTaskInMenuBar) ?? false
        pinnedMenuBarTaskID = try container.decodeIfPresent(UUID.self, forKey: .pinnedMenuBarTaskID)
    }
}

struct NoteItem: Identifiable, Codable, Equatable {
    let id: UUID
    var content: String
    let createdAt: Date
    var updatedAt: Date

    init(id: UUID = UUID(), content: String, createdAt: Date = .now, updatedAt: Date = .now) {
        self.id = id
        self.content = content
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }
}

struct AppData: Codable {
    var tasks: [TaskItem] = []
    var notes: [NoteItem] = []
    var categories: [AppCategory] = []
    var preferences: AppPreferences = .init()
}
