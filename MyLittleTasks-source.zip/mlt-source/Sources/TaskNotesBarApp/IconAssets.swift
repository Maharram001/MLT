import AppKit
import SwiftUI

enum MenuBarIconAsset {
    static let taskly = "taskly.frame67"

    static func image(for identifier: String) -> NSImage? {
        guard identifier == taskly else { return nil }

        let url = Bundle.main.url(forResource: "Frame69", withExtension: "svg")
            ?? Bundle.module.url(forResource: "Frame69", withExtension: "svg", subdirectory: "Resources")
        guard let url,
              let image = NSImage(contentsOf: url) else {
            return nil
        }

        image.isTemplate = true
        image.size = NSSize(width: 18, height: 18)
        return image
    }
}

struct MenuBarIconGlyph: View {
    let identifier: String

    var body: some View {
        Group {
            if let image = MenuBarIconAsset.image(for: identifier) {
                Image(nsImage: image)
                    .resizable()
                    .scaledToFit()
            } else {
                Image(systemName: identifier)
                    .resizable()
                    .scaledToFit()
            }
        }
    }
}
