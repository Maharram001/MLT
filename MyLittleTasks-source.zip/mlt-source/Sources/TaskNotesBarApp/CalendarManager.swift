import AppKit
import EventKit
import SwiftUI

struct CalendarEventItem: Identifiable, Equatable {
    let id: String
    let title: String
    let calendarTitle: String
    let startDate: Date
    let endDate: Date
    let isAllDay: Bool

    var duration: TimeInterval {
        endDate.timeIntervalSince(startDate)
    }
}

@MainActor
final class CalendarManager: ObservableObject {
    @Published private(set) var authorizationStatus: EKAuthorizationStatus
    @Published private(set) var todaysEvents: [CalendarEventItem] = []
    @Published private(set) var errorMessage: String?

    private let eventStore = EKEventStore()
    private var eventStoreObserver: NSObjectProtocol?

    init() {
        authorizationStatus = EKEventStore.authorizationStatus(for: .event)
        eventStoreObserver = NotificationCenter.default.addObserver(
            forName: .EKEventStoreChanged,
            object: eventStore,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor in
                self?.refreshToday()
            }
        }
        if hasCalendarAccess {
            refreshToday()
        }
    }

    deinit {
        if let eventStoreObserver {
            NotificationCenter.default.removeObserver(eventStoreObserver)
        }
    }

    var hasCalendarAccess: Bool {
        switch authorizationStatus {
        case .authorized, .fullAccess:
            return true
        default:
            return false
        }
    }

    var nextShortEvent: CalendarEventItem? {
        let now = Date()
        let oneHourFromNow = now.addingTimeInterval(60 * 60)
        return todaysEvents
            .filter { !$0.isAllDay && $0.startDate >= now && $0.startDate <= oneHourFromNow }
            .sorted { $0.startDate < $1.startDate }
            .first
    }

    func requestAccess() {
        Task {
            do {
                let granted: Bool
                if #available(macOS 14.0, *) {
                    granted = try await eventStore.requestFullAccessToEvents()
                } else {
                    granted = try await eventStore.requestAccess(to: .event)
                }
                authorizationStatus = EKEventStore.authorizationStatus(for: .event)
                if granted {
                    errorMessage = nil
                    refreshToday()
                } else {
                    todaysEvents = []
                    errorMessage = "Calendar access was not granted. You can enable it in System Settings."
                }
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    func refreshToday() {
        authorizationStatus = EKEventStore.authorizationStatus(for: .event)
        guard hasCalendarAccess else {
            todaysEvents = []
            return
        }

        let calendar = Calendar.current
        let start = calendar.startOfDay(for: Date())
        let end = calendar.date(byAdding: .day, value: 1, to: start) ?? Date()
        let predicate = eventStore.predicateForEvents(withStart: start, end: end, calendars: nil)

        todaysEvents = eventStore.events(matching: predicate)
            .filter { !$0.isDetached }
            .map {
                CalendarEventItem(
                    id: $0.eventIdentifier ?? UUID().uuidString,
                    title: cleanedTitle($0.title),
                    calendarTitle: $0.calendar.title,
                    startDate: $0.startDate,
                    endDate: $0.endDate,
                    isAllDay: $0.isAllDay
                )
            }
            .sorted { $0.startDate < $1.startDate }
    }

    func openNewEvent(target: CalendarNewEventTarget) {
        let url: URL?
        switch target {
        case .apple:
            url = URL(string: "calendar://")
        case .google:
            url = URL(string: "https://calendar.google.com/calendar/render?action=TEMPLATE")
        case .outlook:
            url = URL(string: "https://outlook.live.com/calendar/0/deeplink/compose")
        }

        if let url {
            NSWorkspace.shared.open(url)
        }
    }

    func openCalendarAccountSettings() {
        let candidates = [
            "x-apple.systempreferences:com.apple.Internet-Accounts-Settings.extension",
            "x-apple.systempreferences:com.apple.preference.internetaccounts"
        ]
        if let url = candidates.compactMap(URL.init(string:)).first {
            NSWorkspace.shared.open(url)
        }
    }

    private func cleanedTitle(_ title: String?) -> String {
        let cleaned = title?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return cleaned.isEmpty ? "Untitled event" : cleaned
    }
}
