import Foundation

@MainActor
final class AppStore: ObservableObject {
    @Published private(set) var tasks: [TaskItem] = []
    @Published private(set) var notes: [NoteItem] = []
    @Published private(set) var categories: [AppCategory] = []
    @Published private(set) var preferences: AppPreferences = .init()

    var onPreferencesChanged: ((AppPreferences) -> Void)?
    var onDataChanged: (() -> Void)?

    private let encoder = JSONEncoder()
    private let decoder = JSONDecoder()
    private let dataURL: URL
    private let backupDirectoryURL: URL

    var backupDirectory: URL {
        backupDirectoryURL
    }

    init() {
        let fm = FileManager.default
        let appSupport = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask).first ?? URL(fileURLWithPath: NSTemporaryDirectory())
        let dir = appSupport.appendingPathComponent("TaskNotesBarApp", isDirectory: true)
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
        dataURL = dir.appendingPathComponent("data.json")
        let documents = fm.urls(for: .documentDirectory, in: .userDomainMask).first ?? appSupport
        backupDirectoryURL = documents
            .appendingPathComponent("MyLittleTasks", isDirectory: true)
            .appendingPathComponent("backup", isDirectory: true)

        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        decoder.dateDecodingStrategy = .iso8601
        load()
    }

    func addTask(from input: String) {
        let trimmed = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }

        let parsed = parseTaskInput(trimmed)
        if let category = parsed.category {
            ensureCategoryExists(named: category)
        }
        let task = TaskItem(title: parsed.title, category: parsed.category)
        tasks.insert(task, at: 0)
        save()
    }

    func addTask(title: String, category: String?) {
        let trimmedTitle = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedTitle.isEmpty else { return }

        let trimmedCategory = category?.trimmingCharacters(in: .whitespacesAndNewlines).nilIfEmpty
        if let trimmedCategory {
            ensureCategoryExists(named: trimmedCategory)
        }

        tasks.insert(TaskItem(title: trimmedTitle, category: trimmedCategory), at: 0)
        save()
    }

    func addSubtask(title: String, parentTaskID: UUID) {
        let trimmedTitle = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedTitle.isEmpty else { return }
        guard let parentIndex = tasks.firstIndex(where: { $0.id == parentTaskID }) else { return }

        let parent = tasks[parentIndex]
        let subtask = TaskItem(
            title: trimmedTitle,
            category: parent.category,
            parentTaskID: parentTaskID
        )

        let insertionIndex = descendantInsertionIndex(for: parentTaskID, startingAt: parentIndex)
        tasks.insert(subtask, at: insertionIndex)
        save()
    }

    func updateTask(id: UUID, title: String, category: String?) {
        guard let idx = tasks.firstIndex(where: { $0.id == id }) else { return }
        let trimmedTitle = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedTitle.isEmpty else { return }
        let normalizedCategory = category?.trimmingCharacters(in: .whitespacesAndNewlines).nilIfEmpty
        tasks[idx].title = trimmedTitle
        tasks[idx].category = normalizedCategory
        let descendantIDs = descendantTaskIDs(of: id)
        for descendantIndex in tasks.indices where descendantIDs.contains(tasks[descendantIndex].id) {
            tasks[descendantIndex].category = normalizedCategory
        }
        save()
    }

    func toggleTaskCompletion(id: UUID, isCompleted: Bool) {
        guard let idx = tasks.firstIndex(where: { $0.id == id }) else { return }
        tasks[idx].isCompleted = isCompleted
        save()
    }

    func deleteTask(id: UUID) {
        let descendantIDs = descendantTaskIDs(of: id)
        clearPinnedTaskIfNeeded(removing: descendantIDs.union([id]))
        tasks.removeAll { $0.id == id || descendantIDs.contains($0.id) }
        save()
    }

    func deleteTasks(ids: Set<UUID>) {
        guard !ids.isEmpty else { return }
        let descendantIDs = ids.reduce(into: Set<UUID>()) { result, id in
            result.formUnion(descendantTaskIDs(of: id))
        }
        clearPinnedTaskIfNeeded(removing: descendantIDs.union(ids))
        tasks.removeAll { ids.contains($0.id) || descendantIDs.contains($0.id) }
        save()
    }

    func deleteCategory(named category: String) {
        let removedIDs = Set(tasks.filter { categoryKey(for: $0.category) == category }.map(\.id))
        clearPinnedTaskIfNeeded(removing: removedIDs)
        categories.removeAll { $0.name == category }
        if category == "General" {
            tasks.removeAll { task in
                let cleaned = task.category?.trimmingCharacters(in: .whitespacesAndNewlines).nilIfEmpty
                return cleaned == nil
            }
        } else {
            tasks.removeAll { task in
                let cleaned = task.category?.trimmingCharacters(in: .whitespacesAndNewlines).nilIfEmpty
                return cleaned == category
            }
        }
        save()
    }

    func category(named name: String) -> AppCategory? {
        categories.first { $0.name == name }
    }

    @discardableResult
    func renameCategory(oldName: String, newName: String) -> Bool {
        let trimmed = newName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard oldName != "General", !trimmed.isEmpty else { return false }
        guard categories.contains(where: { $0.name == oldName }) else { return false }
        guard !categories.contains(where: { $0.name == trimmed && $0.name != oldName }) else { return false }

        if let index = categories.firstIndex(where: { $0.name == oldName }) {
            categories[index].name = trimmed
        }

        for index in tasks.indices where tasks[index].category == oldName {
            tasks[index].category = trimmed
        }

        save()
        return true
    }

    func setCategoryIcon(named name: String, iconFilePath: String?) {
        guard let index = categories.firstIndex(where: { $0.name == name }) else { return }
        categories[index].iconFilePath = iconFilePath
        categories[index].iconEmoji = nil
        save()
    }

    func setCategoryEmoji(named name: String, emoji: String?) {
        guard let index = categories.firstIndex(where: { $0.name == name }) else { return }
        categories[index].iconEmoji = emoji?.trimmingCharacters(in: .whitespacesAndNewlines).nilIfEmpty
        categories[index].iconFilePath = nil
        save()
    }

    func setCategoryIconSystemName(named name: String, systemName: String) {
        guard let index = categories.firstIndex(where: { $0.name == name }) else { return }
        categories[index].iconSystemName = systemName
        categories[index].iconEmoji = nil
        categories[index].iconFilePath = nil
        save()
    }

    func setMenuBarIcon(systemName: String) {
        preferences.menuBarIconSystemName = systemName
        onPreferencesChanged?(preferences)
        save()
    }

    func setTintStyle(_ tintStyle: AppTintStyle) {
        preferences.tintStyle = tintStyle
        onPreferencesChanged?(preferences)
        save()
    }

    func setCustomTintHex(_ hex: String) {
        preferences.tintStyle = .custom
        preferences.customTintHex = hex
        onPreferencesChanged?(preferences)
        save()
    }

    func setLaunchAtLogin(_ enabled: Bool) {
        preferences.launchAtLogin = enabled
        save()
    }

    func setMarqueeLongTaskTitles(_ enabled: Bool) {
        preferences.marqueeLongTaskTitles = enabled
        save()
    }

    func setAutoBackupFrequency(_ frequency: AutoBackupFrequency) {
        preferences.autoBackupFrequency = frequency
        if frequency == .off {
            preferences.lastAutoBackupAt = nil
        }
        save()
    }

    func setCalendarNewEventTarget(_ target: CalendarNewEventTarget) {
        preferences.calendarNewEventTarget = target
        save()
    }

    func setShowPinnedTaskInMenuBar(_ enabled: Bool) {
        preferences.showPinnedTaskInMenuBar = enabled
        onPreferencesChanged?(preferences)
        save()
    }

    func setPinnedMenuBarTask(id: UUID?) {
        preferences.pinnedMenuBarTaskID = id
        onPreferencesChanged?(preferences)
        save()
    }

    func moveCategory(named name: String, direction: CategoryMoveDirection) {
        guard let index = categories.firstIndex(where: { $0.name == name }) else { return }

        let newIndex: Int
        switch direction {
        case .up:
            guard index > 0 else { return }
            newIndex = index - 1
        case .down:
            guard index < categories.count - 1 else { return }
            newIndex = index + 1
        }

        let category = categories.remove(at: index)
        categories.insert(category, at: newIndex)
        save()
    }

    func moveCategory(named draggedName: String, relativeTo targetName: String, position: CategoryDropPosition) {
        guard draggedName != targetName else { return }
        guard let fromIndex = categories.firstIndex(where: { $0.name == draggedName }) else { return }
        guard let targetIndex = categories.firstIndex(where: { $0.name == targetName }) else { return }

        let category = categories.remove(at: fromIndex)
        var insertionIndex = targetIndex

        if fromIndex < targetIndex {
            insertionIndex -= 1
        }

        if position == .after {
            insertionIndex += 1
        }

        insertionIndex = max(0, min(categories.count, insertionIndex))
        categories.insert(category, at: insertionIndex)
        save()
    }

    func upsertNote(id: UUID?, content: String) {
        let trimmed = content.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }

        if let id, let idx = notes.firstIndex(where: { $0.id == id }) {
            notes[idx].content = trimmed
            notes[idx].updatedAt = .now
        } else {
            notes.insert(NoteItem(content: trimmed), at: 0)
        }

        notes.sort { $0.updatedAt > $1.updatedAt }
        save()
    }

    func deleteNote(id: UUID) {
        notes.removeAll { $0.id == id }
        save()
    }

    func exportTasks(to url: URL) throws {
        let data = try encoder.encode(tasks)
        try data.write(to: url, options: .atomic)
    }

    func exportNotes(to url: URL) throws {
        let data = try encoder.encode(notes)
        try data.write(to: url, options: .atomic)
    }

    func importTasks(from url: URL) throws {
        let data = try Data(contentsOf: url)
        if let decoded = decodeTasks(from: data) {
            tasks = decoded
            categories = inferredCategories(from: decoded)
            clearPinnedTaskIfMissing()
            save()
            return
        }

        let payload = try decodeAppData(from: data)
        tasks = payload.tasks
        categories = payload.categories.isEmpty ? inferredCategories(from: payload.tasks) : payload.categories
        clearPinnedTaskIfMissing()
        save()
    }

    func importNotes(from url: URL) throws {
        let data = try Data(contentsOf: url)
        if let decoded = decodeNotes(from: data) {
            notes = decoded
            save()
            return
        }

        let payload = try decodeAppData(from: data)
        notes = payload.notes
        save()
    }

    private func parseTaskInput(_ text: String) -> (category: String?, title: String) {
        let pieces = text.split(separator: " ", maxSplits: 1, omittingEmptySubsequences: true)
        guard let first = pieces.first, first.hasPrefix("#") else {
            return (nil, text)
        }

        let category = String(first.dropFirst()).trimmingCharacters(in: .whitespacesAndNewlines)
        let title = pieces.count > 1 ? String(pieces[1]).trimmingCharacters(in: .whitespacesAndNewlines) : ""

        if category.isEmpty || title.isEmpty {
            return (nil, text)
        }

        return (category, title)
    }

    private func categoryKey(for category: String?) -> String {
        let cleaned = category?.trimmingCharacters(in: .whitespacesAndNewlines).nilIfEmpty
        return cleaned ?? "General"
    }

    private func load() {
        guard let data = try? Data(contentsOf: dataURL) else { return }
        guard let decoded = try? decoder.decode(AppData.self, from: data) else { return }
        tasks = decoded.tasks
        notes = decoded.notes
        categories = decoded.categories.isEmpty ? inferredCategories(from: decoded.tasks) : decoded.categories
        preferences = decoded.preferences
    }

    private func save(runAutoBackup: Bool = true) {
        let payload = AppData(tasks: tasks, notes: notes, categories: categories, preferences: preferences)
        guard let data = try? encoder.encode(payload) else { return }
        try? data.write(to: dataURL, options: .atomic)
        onDataChanged?()
        if runAutoBackup {
            performAutoBackupIfNeeded(using: payload)
        }
    }

    private func ensureCategoryExists(named name: String) {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, trimmed != "General" else { return }
        guard !categories.contains(where: { $0.name == trimmed }) else { return }
        let icon = preferences.menuBarIconSystemName == MenuBarIconAsset.taskly
            ? "checklist.checked"
            : preferences.menuBarIconSystemName
        categories.append(AppCategory(name: trimmed, iconSystemName: icon))
    }

    private func inferredCategories(from tasks: [TaskItem]) -> [AppCategory] {
        var seen: Set<String> = []
        var inferred: [AppCategory] = []

        for task in tasks {
            guard let name = task.category?.trimmingCharacters(in: .whitespacesAndNewlines).nilIfEmpty else { continue }
            guard name != "General", !seen.contains(name) else { continue }
            seen.insert(name)
            inferred.append(AppCategory(name: name))
        }

        return inferred
    }

    private func descendantInsertionIndex(for parentTaskID: UUID, startingAt parentIndex: Int) -> Int {
        let descendantIDs = descendantTaskIDs(of: parentTaskID)
        var insertionIndex = parentIndex + 1

        while insertionIndex < tasks.count {
            let task = tasks[insertionIndex]
            guard descendantIDs.contains(task.id) else { break }
            insertionIndex += 1
        }

        return insertionIndex
    }

    private func descendantTaskIDs(of id: UUID) -> Set<UUID> {
        var result: Set<UUID> = []
        var queue: [UUID] = [id]

        while let current = queue.first {
            queue.removeFirst()
            let children = tasks.filter { $0.parentTaskID == current }.map(\.id)
            for childID in children where !result.contains(childID) {
                result.insert(childID)
                queue.append(childID)
            }
        }

        return result
    }

    private func clearPinnedTaskIfNeeded(removing ids: Set<UUID>) {
        guard let pinnedID = preferences.pinnedMenuBarTaskID, ids.contains(pinnedID) else { return }
        preferences.pinnedMenuBarTaskID = nil
        onPreferencesChanged?(preferences)
    }

    private func clearPinnedTaskIfMissing() {
        guard let pinnedID = preferences.pinnedMenuBarTaskID,
              !tasks.contains(where: { $0.id == pinnedID }) else { return }
        preferences.pinnedMenuBarTaskID = nil
        onPreferencesChanged?(preferences)
    }

    private func decodeTasks(from data: Data) -> [TaskItem]? {
        if let decoded = try? decoder.decode([TaskItem].self, from: data) {
            return decoded
        }
        let fallback = JSONDecoder()
        return try? fallback.decode([TaskItem].self, from: data)
    }

    private func decodeNotes(from data: Data) -> [NoteItem]? {
        if let decoded = try? decoder.decode([NoteItem].self, from: data) {
            return decoded
        }
        let fallback = JSONDecoder()
        return try? fallback.decode([NoteItem].self, from: data)
    }

    private func decodeAppData(from data: Data) throws -> AppData {
        if let decoded = try? decoder.decode(AppData.self, from: data) {
            return decoded
        }
        let fallback = JSONDecoder()
        return try fallback.decode(AppData.self, from: data)
    }

    private func performAutoBackupIfNeeded(using payload: AppData) {
        guard shouldPerformAutoBackup(now: .now) else { return }
        let fm = FileManager.default
        try? fm.createDirectory(at: backupDirectoryURL, withIntermediateDirectories: true)
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withDashSeparatorInDate, .withColonSeparatorInTime]
        let fileName = "backup-\(formatter.string(from: .now).replacingOccurrences(of: ":", with: "-")).json"
        let fileURL = backupDirectoryURL.appendingPathComponent(fileName)
        guard let data = try? encoder.encode(payload) else { return }
        do {
            try data.write(to: fileURL, options: .atomic)
            preferences.lastAutoBackupAt = .now
            let updatedPayload = AppData(tasks: tasks, notes: notes, categories: categories, preferences: preferences)
            if let updatedData = try? encoder.encode(updatedPayload) {
                try? updatedData.write(to: dataURL, options: .atomic)
            }
        } catch {
            return
        }
    }

    private func shouldPerformAutoBackup(now: Date) -> Bool {
        let frequency = preferences.autoBackupFrequency
        guard frequency != .off else { return false }
        guard let lastAutoBackupAt = preferences.lastAutoBackupAt else { return true }
        let interval: TimeInterval
        switch frequency {
        case .off:
            return false
        case .daily:
            interval = 60 * 60 * 24
        case .weekly:
            interval = 60 * 60 * 24 * 7
        case .monthly:
            interval = 60 * 60 * 24 * 30
        }
        return now.timeIntervalSince(lastAutoBackupAt) >= interval
    }
}

enum CategoryMoveDirection {
    case up
    case down
}

enum CategoryDropPosition {
    case before
    case after
}

private extension String {
    var nilIfEmpty: String? {
        isEmpty ? nil : self
    }
}
