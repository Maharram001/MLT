import AppKit
import CoreImage.CIFilterBuiltins
import QuartzCore
import SwiftUI
import UniformTypeIdentifiers
#if canImport(ServiceManagement)
import ServiceManagement
#endif

enum AppSection: String, CaseIterable, Identifiable {
    case tasks = "Tasks"
    case notes = "Notes"

    var id: String { rawValue }
}

struct MenuBarContentView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var noteEditor: NoteEditorCoordinator
    @EnvironmentObject private var calendarManager: CalendarManager

    @State private var section: AppSection = .tasks
    @State private var expandedArchivedCategories: Set<String> = []
    @State private var newTaskText = ""
    @State private var editingTaskID: UUID?
    @State private var editingTaskText = ""
    @State private var editingCategoryName: String?
    @State private var editingCategoryText = ""
    @State private var editingCategoryIconName: String?
    @State private var addingTaskCategoryName: String?
    @State private var addingTaskText = ""
    @State private var addingSubtaskParentID: UUID?
    @State private var addingSubtaskText = ""
    @State private var hoveredTaskID: UUID?
    @State private var expandedTaskIDs: Set<UUID> = []
    @State private var isDeleteMode = false
    @State private var isReorderMode = false
    @State private var selectedTaskIDs: Set<UUID> = []
    @State private var chipScrollContentMinX: CGFloat = 0
    @State private var chipScrollContentWidth: CGFloat = 0
    @State private var chipScrollViewportWidth: CGFloat = 0
    @State private var statisticsRangeStart = Calendar.current.startOfDay(for: .now)
    @State private var statisticsRangeEnd = Calendar.current.startOfDay(for: .now)
    @State private var selectedStatisticsRange: ClosedRange<Date>?
    @State private var statisticsMonthSelection = Calendar.current.component(.month, from: Date.now)
    @State private var statisticsYearSelection = Calendar.current.component(.year, from: Date.now)
    @State private var draggedCategoryName: String?
    @State private var dropTargetCategoryName: String?
    @State private var dropTargetPosition: CategoryDropPosition = .before
    @State private var draggedCategoryOffset: CGSize = .zero
    @State private var categoryFrames: [String: CGRect] = [:]
    @State private var reorderViewportRect: CGRect = .zero
    @State private var taskListContentRect: CGRect = .zero
    @State private var isStatisticsPopoverPresented = false
    @State private var isSettingsPopoverPresented = false
    @FocusState private var focusedNewTaskField: Bool

    private var completedCount: Int {
        visibleTasks.filter(\.isCompleted).count
    }

    private var remainingCount: Int {
        visibleTasks.count - completedCount
    }

    private var categoryCount: Int {
        groupedTasks.count
    }

    private var upcomingEventCount: Int {
        let now = Date()
        return calendarManager.todaysEvents.filter { !$0.isAllDay && $0.endDate >= now }.count
    }

    private var statisticsYears: [Int] {
        let years = Set(store.tasks.map { Calendar.current.component(.year, from: $0.createdAt) })
        return years.sorted(by: >)
    }

    private var shouldShowStatsLeadingFade: Bool {
        chipScrollContentMinX < -2
    }

    private var shouldShowStatsTrailingFade: Bool {
        chipScrollContentWidth + chipScrollContentMinX > chipScrollViewportWidth + 2
    }

    private var groupedTasks: [TaskCategoryGroup] {
        let bucketed = Dictionary(grouping: visibleTasks, by: { categoryLabel(for: $0.category) })
        var groups: [TaskCategoryGroup] = []
        var seen: Set<String> = []

        for category in store.categories {
            let tasks = bucketed[category.name] ?? []
            guard !tasks.isEmpty else { continue }
            groups.append(TaskCategoryGroup(id: category.name, title: category.name, category: category, tasks: tasks))
            seen.insert(category.name)
        }

        if let generalTasks = bucketed["General"], !generalTasks.isEmpty {
            groups.append(TaskCategoryGroup(id: "General", title: "General", category: nil, tasks: generalTasks))
            seen.insert("General")
        }

        for (name, tasks) in bucketed where !seen.contains(name) {
            groups.append(TaskCategoryGroup(id: name, title: name, category: store.category(named: name), tasks: tasks))
        }

        return groups
    }

    private var visibleTasks: [TaskItem] {
        guard let selectedStatisticsRange else { return store.tasks }
        let range = normalizedStatisticsRange(from: selectedStatisticsRange)
        return store.tasks.filter { range.contains($0.createdAt) }
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            VStack(alignment: .leading, spacing: 16) {
                topTabs

                switch section {
                case .tasks:
                    tasksView
                case .notes:
                    notesView
                }
            }
            .padding(16)

            if section == .tasks && shouldShowTaskListTopFade {
                ProgressiveBlurView(maxBlurRadius: 18, direction: .blurredTopClearBottom, startOffset: -0.08)
                    .frame(height: 64)
                    .frame(maxWidth: .infinity)
                    .allowsHitTesting(false)
                    .transition(.opacity)
                    .mask(
                        LinearGradient(
                            colors: [.white, .white.opacity(0.8), .white.opacity(0.35), .clear],
                            startPoint: .top,
                            endPoint: .bottom
                        )
                    )
                    .frame(maxHeight: .infinity, alignment: .top)
            }

            if section == .tasks && shouldShowTaskListBottomFade {
                ProgressiveBlurView(maxBlurRadius: 18, direction: .blurredBottomClearTop, startOffset: -0.08)
                    .frame(height: 64)
                    .frame(maxWidth: .infinity)
                    .allowsHitTesting(false)
                    .transition(.opacity)
                    .mask(
                        LinearGradient(
                            colors: [.clear, .white.opacity(0.35), .white.opacity(0.8), .white],
                            startPoint: .top,
                            endPoint: .bottom
                        )
                    )
                    .frame(maxHeight: .infinity, alignment: .bottom)
            }
        }
        .frame(minWidth: 340, minHeight: 500, alignment: .topLeading)
        .fontDesign(.rounded)
        .background(Color.clear)
        .coordinateSpace(name: "panel-root")
        .ignoresSafeArea(.container, edges: .top)
    }

    private var shouldShowTaskListTopFade: Bool {
        guard reorderViewportRect != .zero, taskListContentRect != .zero else { return false }
        return taskListContentRect.minY < reorderViewportRect.minY - 6
    }

    private var shouldShowTaskListBottomFade: Bool {
        guard reorderViewportRect != .zero, taskListContentRect != .zero else { return false }
        return taskListContentRect.maxY - reorderViewportRect.maxY > 6
    }

    private var topTabs: some View {
        HStack(spacing: 16) {
            tabButton(title: "Tasks", value: .tasks)
            tabButton(title: "Notes", value: .notes)
            Spacer(minLength: 0)

            if section == .tasks {
                reorderModeButton
                deleteModeButton
            }

            settingsButton
        }
        .frame(height: 28)
    }

    private var deleteModeButton: some View {
        Button {
            if isDeleteMode {
                selectedTaskIDs.removeAll()
            }
            isDeleteMode.toggle()
            if isDeleteMode {
                isReorderMode = false
            }
            editingTaskID = nil
            editingCategoryName = nil
        } label: {
            Image(systemName: isDeleteMode ? "trash.fill" : "trash")
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(isDeleteMode ? Color.red.opacity(0.92) : .white.opacity(0.9))
                .frame(width: 24, height: 24)
        }
        .buttonStyle(.plain)
    }

    private var reorderModeButton: some View {
        Button {
            isReorderMode.toggle()
            if isReorderMode {
                isDeleteMode = false
                selectedTaskIDs.removeAll()
            } else {
                clearCategoryDragState()
            }
        } label: {
            Image(systemName: isReorderMode ? "checkmark" : "circle.grid.2x2")
                .font(.system(size: 11, weight: .semibold))
                .foregroundStyle(isReorderMode ? .white : .white.opacity(0.9))
                .frame(width: 18, height: 18)
        }
        .buttonStyle(.plain)
    }

    private var settingsButton: some View {
        Button {
            isSettingsPopoverPresented.toggle()
        } label: {
            Image(systemName: "gearshape")
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(.white.opacity(0.9))
                .frame(width: 24, height: 24)
        }
        .buttonStyle(.plain)
        .popover(isPresented: $isSettingsPopoverPresented, attachmentAnchor: .point(.bottom), arrowEdge: .top) {
            SettingsPopoverView(
                preferences: store.preferences,
                backupLocation: store.backupDirectory.path,
                onIconSelected: store.setMenuBarIcon,
                onTintSelected: store.setTintStyle,
                onCustomTintSelected: store.setCustomTintHex,
                onLaunchAtLoginChanged: applyLaunchAtLogin,
                onMarqueeChanged: store.setMarqueeLongTaskTitles,
                onAutoBackupFrequencyChanged: store.setAutoBackupFrequency,
                onCalendarTargetChanged: store.setCalendarNewEventTarget,
                onShowPinnedTaskChanged: store.setShowPinnedTaskInMenuBar,
                onRequestCalendarAccess: calendarManager.requestAccess,
                onOpenCalendarSettings: calendarManager.openCalendarAccountSettings,
                onOpenBackupLocation: openBackupLocation,
                onExportTasks: exportTasks,
                onImportTasks: importTasks,
                onExportNotes: exportNotes,
                onImportNotes: importNotes,
                onQuit: { NSApplication.shared.terminate(nil) }
            )
            .presentationBackground(.ultraThickMaterial)
            .presentationCornerRadius(16)
        }
    }

    private func tabButton(title: String, value: AppSection) -> some View {
        Button {
            section = value
            isDeleteMode = false
            selectedTaskIDs.removeAll()
        } label: {
            Text(title)
                .font(.system(size: 18, weight: section == value ? .semibold : .regular))
                .foregroundStyle(section == value ? .primary : .secondary)
        }
        .buttonStyle(.plain)
    }

    private var tasksView: some View {
        VStack(alignment: .leading, spacing: 8) {
            nextEventBanner

            TextField("Create a new task (#new category)", text: $newTaskText)
                .focused($focusedNewTaskField)
                .font(.system(size: 13, weight: .regular))
                .foregroundStyle(.secondary)
                .textFieldStyle(.plain)
                .padding(.leading, 8)
                .padding(.trailing, 6)
                .frame(height: 28)
                .background(fieldBackground)
                .onSubmit {
                    store.addTask(from: newTaskText)
                    newTaskText = ""
                }

            taskStatisticsRow

            if store.tasks.isEmpty {
                ContentUnavailableView("No tasks", systemImage: "checklist")
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                ZStack(alignment: .topLeading) {
                    ScrollView(showsIndicators: false) {
                        LazyVStack(alignment: .leading, spacing: 8) {
                            ForEach(groupedTasks) { group in
                                categorySectionContainer(group)
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .topLeading)
                        .background(
                            GeometryReader { proxy in
                                Color.clear.preference(
                                    key: TaskListContentPreferenceKey.self,
                                    value: proxy.frame(in: .named("category-reorder"))
                                )
                            }
                        )
                    }
                    .coordinateSpace(name: "category-reorder")
                    .background(
                        GeometryReader { proxy in
                            Color.clear
                                .preference(key: ReorderViewportPreferenceKey.self, value: proxy.frame(in: .named("category-reorder")))
                        }
                    )
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                    .animation(.smooth(duration: 0.28), value: store.categories)
                    .animation(.smooth(duration: 0.22), value: dropTargetCategoryName)
                    .onPreferenceChange(CategoryFramePreferenceKey.self) { categoryFrames = $0 }
                    .onPreferenceChange(ReorderViewportPreferenceKey.self) { reorderViewportRect = $0 }
                    .onPreferenceChange(TaskListContentPreferenceKey.self) { taskListContentRect = $0 }

                    if let draggedCategoryName,
                       let draggedGroup = groupedTasks.first(where: { $0.title == draggedCategoryName }),
                       let frame = categoryFrames[draggedCategoryName] {
                        categorySection(draggedGroup)
                            .frame(width: frame.width)
                            .offset(x: clampedDragOffset.width + frame.minX, y: clampedDragOffset.height + frame.minY)
                            .scaleEffect(1.025)
                            .rotation3DEffect(
                                .degrees(Double(-draggedCategoryOffset.width * 0.045)),
                                axis: (x: 0, y: 1, z: 0),
                                anchor: draggedCategoryOffset.width < 0 ? .trailing : .leading,
                                perspective: 0.9
                            )
                            .shadow(color: .black.opacity(0.24), radius: 22, y: 12)
                            .zIndex(100)
                            .allowsHitTesting(false)
                            .animation(.interactiveSpring(response: 0.42, dampingFraction: 0.92, blendDuration: 0.12), value: draggedCategoryOffset)
                    }
                }
            }

            if isDeleteMode {
                deleteActionBar
            }
        }
    }

    @ViewBuilder
    private var nextEventBanner: some View {
        if let event = calendarManager.nextShortEvent {
            HStack(spacing: 8) {
                Image(systemName: "calendar.badge.clock")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(store.preferences.tintColor)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Next event")
                        .font(.system(size: 10, weight: .medium))
                        .foregroundStyle(.secondary)
                    Text("\(event.title) · \(eventTimeRange(event))")
                        .font(.system(size: 12, weight: .semibold))
                        .lineLimit(1)
                }
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 10)
            .frame(height: 42)
            .background(cardBackground)
        }
    }

    private func eventTimeRange(_ event: CalendarEventItem) -> String {
        if event.isAllDay { return "All day" }
        return "\(event.startDate.formatted(date: .omitted, time: .shortened)) - \(event.endDate.formatted(date: .omitted, time: .shortened))"
    }

    private func categorySectionContainer(_ group: TaskCategoryGroup) -> some View {
        VStack(spacing: 6) {
            if dropTargetCategoryName == group.title && dropTargetPosition == .before && draggedCategoryName != group.title {
                categoryDropPlaceholder
            }

            categorySection(group)
                .background(
                    GeometryReader { proxy in
                        Color.clear.preference(
                            key: CategoryFramePreferenceKey.self,
                            value: [group.title: proxy.frame(in: .named("category-reorder"))]
                        )
                    }
                )
                .opacity(draggedCategoryName == group.title ? 0.12 : 1)
                .gesture(categoryDragGesture(for: group))

            if dropTargetCategoryName == group.title && dropTargetPosition == .after && draggedCategoryName != group.title {
                categoryDropPlaceholder
            }
        }
    }

    private var categoryDropPlaceholder: some View {
        RoundedRectangle(cornerRadius: 8, style: .continuous)
            .fill(.white.opacity(0.05))
            .overlay(
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .strokeBorder(.white.opacity(0.22), style: StrokeStyle(lineWidth: 1, dash: [5, 4]))
            )
            .frame(height: 56)
    }

    private var taskStatisticsRow: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                statisticChip(
                    title: "\(completedCount) checked",
                    systemImage: "checkmark.circle.fill",
                    color: positiveTintColor
                )
                statisticChip(
                    title: "\(remainingCount) remaining",
                    systemImage: "clock.fill",
                    color: remainingTintColor
                )
                taskDeltaChip
                statisticChip(
                    title: "\(categoryCount) categories",
                    systemImage: "square.grid.2x2.fill",
                    color: .secondary
                )
                if calendarManager.hasCalendarAccess {
                    statisticChip(
                        title: "\(calendarManager.todaysEvents.count) events",
                        systemImage: "calendar",
                        color: .secondary
                    )
                    statisticChip(
                        title: "\(upcomingEventCount) upcoming",
                        systemImage: "calendar.badge.clock",
                        color: remainingTintColor
                    )
                } else {
                    statisticChip(
                        title: "calendar off",
                        systemImage: "calendar.badge.exclamationmark",
                        color: .secondary
                    )
                }
                statisticsRangeButton
            }
            .padding(.trailing, 24)
            .background(
                GeometryReader { proxy in
                    Color.clear
                        .preference(key: ChipScrollMinXPreferenceKey.self, value: proxy.frame(in: .named("chip-scroll")).minX)
                        .preference(key: ChipScrollContentWidthPreferenceKey.self, value: proxy.size.width)
                }
            )
        }
        .coordinateSpace(name: "chip-scroll")
        .compositingGroup()
        .mask(statisticsFadeMask)
        .background(
            GeometryReader { proxy in
                Color.clear
                    .onAppear { chipScrollViewportWidth = proxy.size.width }
                    .onChange(of: proxy.size.width) { _, newValue in
                        chipScrollViewportWidth = newValue
                    }
            }
        )
        .onPreferenceChange(ChipScrollMinXPreferenceKey.self) { chipScrollContentMinX = $0 }
        .onPreferenceChange(ChipScrollContentWidthPreferenceKey.self) { chipScrollContentWidth = $0 }
    }

    private var statisticsRangeButton: some View {
        Button {
            if selectedStatisticsRange == nil {
                isStatisticsPopoverPresented.toggle()
            } else {
                selectedStatisticsRange = nil
            }
        } label: {
            HStack(spacing: 6) {
                Image(systemName: selectedStatisticsRange == nil ? "calendar" : "xmark")
                    .font(.system(size: 11, weight: .semibold))
                if selectedStatisticsRange != nil {
                    Text("Clear")
                        .lineLimit(1)
                }
            }
            .font(.system(size: 12, weight: .medium))
            .foregroundStyle(selectedStatisticsRange == nil ? Color.primary : Color.red)
            .frame(minWidth: selectedStatisticsRange == nil ? 40 : 70)
            .frame(height: 28)
            .background(
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .fill(.thinMaterial)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .strokeBorder(.white.opacity(0.12), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .popover(isPresented: $isStatisticsPopoverPresented, attachmentAnchor: .point(.bottom), arrowEdge: .top) {
            StatisticsRangePickerView(
                startDate: $statisticsRangeStart,
                endDate: $statisticsRangeEnd,
                selectedMonth: $statisticsMonthSelection,
                selectedYear: $statisticsYearSelection,
                availableYears: statisticsYears,
                onApply: {
                    let lower = min(statisticsRangeStart, statisticsRangeEnd)
                    let upper = max(statisticsRangeStart, statisticsRangeEnd)
                    selectedStatisticsRange = lower...upper
                    isStatisticsPopoverPresented = false
                },
                onCancel: {
                    isStatisticsPopoverPresented = false
                }
            )
            .presentationBackground(.ultraThickMaterial)
            .presentationCornerRadius(14)
        }
    }

    private var statisticsFadeMask: some View {
        GeometryReader { proxy in
            let leftVisible = chipScrollContentMinX < -2
            let rightVisible = chipScrollContentWidth + chipScrollContentMinX > chipScrollViewportWidth + 2
            let fadeWidth = min(proxy.size.width * 0.22, 42)

            HStack(spacing: 0) {
                if leftVisible {
                    LinearGradient(
                        stops: [
                            .init(color: .clear, location: 0),
                            .init(color: .white.opacity(0.25), location: 0.38),
                            .init(color: .white, location: 1)
                        ],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                    .frame(width: fadeWidth)
                }

                Rectangle()
                    .fill(.white)

                if rightVisible {
                    LinearGradient(
                        stops: [
                            .init(color: .white, location: 0),
                            .init(color: .white.opacity(0.25), location: 0.62),
                            .init(color: .clear, location: 1)
                        ],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                    .frame(width: fadeWidth)
                }
            }
            .frame(width: proxy.size.width, height: proxy.size.height)
        }
    }

    private var taskDeltaChip: some View {
        HStack(spacing: 6) {
            Text("+\(completedCount)")
                .foregroundStyle(positiveTintColor)
            Text("/")
                .foregroundStyle(.secondary)
            Text("-\(remainingCount)")
                .foregroundStyle(.red)
        }
        .font(.system(size: 12, weight: .medium))
        .padding(.horizontal, 10)
        .frame(height: 28)
        .background(
            RoundedRectangle(cornerRadius: 8, style: .continuous)
                .fill(.thinMaterial)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 8, style: .continuous)
                .strokeBorder(.white.opacity(0.12), lineWidth: 1)
        )
    }

    private func statisticChip(title: String, systemImage: String, color: Color) -> some View {
        HStack(spacing: 6) {
            Image(systemName: systemImage)
                .font(.system(size: 11, weight: .semibold))
            Text(title)
                .lineLimit(1)
        }
        .font(.system(size: 12, weight: .medium))
        .foregroundStyle(color)
        .padding(.horizontal, 10)
        .frame(height: 28)
        .background(
            RoundedRectangle(cornerRadius: 8, style: .continuous)
                .fill(.thinMaterial)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 8, style: .continuous)
                .strokeBorder(.white.opacity(0.12), lineWidth: 1)
        )
    }

    private var deleteActionBar: some View {
        HStack(spacing: 8) {
            Button {
                isDeleteMode = false
                selectedTaskIDs.removeAll()
            } label: {
                Text("Cancel")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.92))
                    .frame(maxWidth: .infinity)
                    .frame(height: 30)
            }
            .buttonStyle(.plain)
            .background(
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .fill(.thinMaterial)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .strokeBorder(.white.opacity(0.12), lineWidth: 1)
            )

            Button {
                store.deleteTasks(ids: selectedTaskIDs)
                selectedTaskIDs.removeAll()
                isDeleteMode = false
            } label: {
                Text("Delete")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(selectedTaskIDs.isEmpty ? .white.opacity(0.45) : .white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 30)
            }
            .buttonStyle(.plain)
            .disabled(selectedTaskIDs.isEmpty)
            .background(
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .fill(selectedTaskIDs.isEmpty ? Color.white.opacity(0.06) : Color.red.opacity(0.22))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .strokeBorder(selectedTaskIDs.isEmpty ? .white.opacity(0.08) : Color.red.opacity(0.28), lineWidth: 1)
            )
        }
        .frame(maxWidth: .infinity)
    }

    private func categorySection(_ group: TaskCategoryGroup) -> some View {
        let activeTasks = activeDisplayTasks(in: group.tasks)
        let archivedTasks = archivedDisplayTasks(in: group.tasks)

        return VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                categoryIconButton(for: group)

                if editingCategoryName == group.title {
                    HStack(spacing: 6) {
                        TextField("Category", text: $editingCategoryText)
                            .textFieldStyle(.plain)
                            .font(.system(size: 12, weight: .regular))
                            .foregroundStyle(.secondary)

                        smallEditButtons(
                            saveAction: {
                                if store.renameCategory(oldName: group.title, newName: editingCategoryText) {
                                    editingCategoryName = nil
                                    editingCategoryText = ""
                                }
                            },
                            cancelAction: {
                                editingCategoryName = nil
                                editingCategoryText = ""
                            }
                        )
                    }
                } else {
                    Text(group.title)
                        .font(.system(size: 12, weight: .regular))
                        .foregroundStyle(.secondary)
                        .contentShape(Rectangle())
                        .onTapGesture {
                            guard group.isEditable, !isDeleteMode else { return }
                            editingCategoryName = group.title
                            editingCategoryText = group.title
                        }
                }

                Spacer(minLength: 0)

                Button {
                    guard !isDeleteMode else { return }
                    addingTaskCategoryName = group.title
                    addingTaskText = ""
                } label: {
                    Image(systemName: "plus")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundStyle(.white.opacity(0.9))
                        .frame(width: 18, height: 18)
                }
                .buttonStyle(.plain)
            }

            VStack(alignment: .leading, spacing: 0) {
                if addingTaskCategoryName == group.title {
                    quickAddRow(for: group)
                }
                ForEach(rootTasks(in: activeTasks)) { task in
                    taskTree(task: task, tasks: activeTasks, depth: 0)
                }
            }

            if !archivedTasks.isEmpty {
                archivedTasksSection(for: group.title, tasks: archivedTasks)
            }
        }
        .padding(8)
        .background(cardBackground)
    }

    private var visualDragOffset: CGSize {
        CGSize(width: draggedCategoryOffset.width * 0.92, height: draggedCategoryOffset.height * 0.92)
    }

    private var clampedDragOffset: CGSize {
        guard let draggedCategoryName,
              let frame = categoryFrames[draggedCategoryName],
              reorderViewportRect != .zero else {
            return visualDragOffset
        }

        let minX = -frame.minX
        let maxX = reorderViewportRect.width - frame.maxX
        let minY = -frame.minY
        let maxY = reorderViewportRect.height - frame.maxY

        return CGSize(
            width: min(max(visualDragOffset.width, minX), maxX),
            height: min(max(visualDragOffset.height, minY), maxY)
        )
    }

    private func categoryDragGesture(for group: TaskCategoryGroup) -> some Gesture {
        DragGesture(minimumDistance: 4)
            .onChanged { value in
                guard isReorderMode, group.isEditable else { return }
                if draggedCategoryName != group.title {
                    draggedCategoryName = group.title
                }
                withAnimation(.interactiveSpring(response: 0.42, dampingFraction: 0.92, blendDuration: 0.10)) {
                    draggedCategoryOffset = value.translation
                    updateDropTarget(for: group.title)
                }
            }
            .onEnded { _ in
                guard isReorderMode, let draggedCategoryName else {
                    clearCategoryDragState()
                    return
                }

                if let dropTargetCategoryName, dropTargetCategoryName != draggedCategoryName {
                    withAnimation(.smooth(duration: 0.30)) {
                        store.moveCategory(named: draggedCategoryName, relativeTo: dropTargetCategoryName, position: dropTargetPosition)
                    }
                }

                clearCategoryDragState()
            }
    }

    private func updateDropTarget(for draggedName: String) {
        guard let draggedFrame = categoryFrames[draggedName] else { return }

        let currentMidY = draggedFrame.midY + clampedDragOffset.height
        let ordered = groupedTasks
            .filter { $0.isEditable && $0.title != draggedName }
            .compactMap { group -> (String, CGRect)? in
                guard let frame = categoryFrames[group.title] else { return nil }
                return (group.title, frame)
            }
            .sorted { $0.1.minY < $1.1.minY }

        guard !ordered.isEmpty else {
            dropTargetCategoryName = nil
            return
        }

        for (name, frame) in ordered {
            if currentMidY < frame.midY {
                dropTargetCategoryName = name
                dropTargetPosition = .before
                return
            }
            if currentMidY >= frame.midY && currentMidY <= frame.maxY {
                dropTargetCategoryName = name
                dropTargetPosition = .after
                return
            }
        }

        if let last = ordered.last {
            dropTargetCategoryName = last.0
            dropTargetPosition = .after
        }
    }

    private func clearCategoryDragState() {
        draggedCategoryName = nil
        dropTargetCategoryName = nil
        dropTargetPosition = .before
        draggedCategoryOffset = .zero
    }

    private func quickAddRow(for group: TaskCategoryGroup) -> some View {
        HStack(spacing: 6) {
            TextField("New task", text: $addingTaskText)
                .font(.system(size: 13, weight: .regular))
                .foregroundStyle(.primary)
                .textFieldStyle(.plain)
                .onSubmit {
                    commitQuickAdd(for: group)
                }

            Spacer(minLength: 0)

            smallEditButtons(
                saveAction: { commitQuickAdd(for: group) },
                cancelAction: {
                    addingTaskCategoryName = nil
                    addingTaskText = ""
                }
            )
        }
        .padding(.leading, 8)
        .padding(.trailing, 6)
        .frame(height: 28)
        .background(fieldBackground)
    }

    private func commitQuickAdd(for group: TaskCategoryGroup) {
        let category = group.title == "General" ? nil : group.title
        store.addTask(title: addingTaskText, category: category)
        addingTaskCategoryName = nil
        addingTaskText = ""
    }

    @ViewBuilder
    private func categoryIconButton(for group: TaskCategoryGroup) -> some View {
        let category = group.category

        Button {
            guard let category else { return }
            editingCategoryIconName = category.name
        } label: {
            CategoryIconView(
                iconSystemName: category?.iconSystemName ?? "checklist.checked",
                iconEmoji: category?.iconEmoji,
                iconFilePath: category?.iconFilePath
            )
        }
        .buttonStyle(.plain)
        .disabled(!group.isEditable || isDeleteMode)
        .popover(
            isPresented: Binding(
                get: { editingCategoryIconName == group.title },
                set: { isPresented in
                    if !isPresented, editingCategoryIconName == group.title {
                        editingCategoryIconName = nil
                    }
                }
            ),
            attachmentAnchor: .point(.bottom),
            arrowEdge: .top
        ) {
            CategoryIconPaletteView(
                selectedSystemName: category?.iconSystemName ?? "checklist.checked",
                onSelect: { icon in
                    store.setCategoryIconSystemName(named: group.title, systemName: icon)
                    editingCategoryIconName = nil
                }
            )
            .presentationBackground(.ultraThinMaterial)
        }
    }

    private func archivedTasksSection(for category: String, tasks: [TaskItem]) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            Button {
                if expandedArchivedCategories.contains(category) {
                    expandedArchivedCategories.remove(category)
                } else {
                    expandedArchivedCategories.insert(category)
                }
            } label: {
                HStack {
                    Text("Checked tasks")
                        .font(.system(size: 13, weight: .regular))
                        .foregroundStyle(.primary)
                    Spacer(minLength: 0)
                    Image(systemName: expandedArchivedCategories.contains(category) ? "chevron.up" : "chevron.down")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(.primary)
                }
                .padding(.horizontal, 12)
                .frame(height: 36)
                .background(
                    RoundedRectangle(cornerRadius: 6, style: .continuous)
                        .fill(.thinMaterial)
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 6, style: .continuous)
                        .strokeBorder(.white.opacity(0.12), lineWidth: 1)
                )
            }
            .buttonStyle(.plain)

            if expandedArchivedCategories.contains(category) {
                VStack(alignment: .leading, spacing: 0) {
                    ForEach(rootTasks(in: tasks)) { task in
                        taskTree(task: task, tasks: tasks, depth: 0)
                    }
                }
                .padding(.top, 8)
            }
        }
    }

    private func taskTree(task: TaskItem, tasks: [TaskItem], depth: Int) -> AnyView {
        let childTasks = children(of: task, in: tasks)

        return AnyView(
            VStack(alignment: .leading, spacing: 0) {
                taskRow(task, depth: depth)

                if addingSubtaskParentID == task.id {
                    subtaskInputRow(parentTaskID: task.id, depth: depth + 1)
                }

                if expandedTaskIDs.contains(task.id) {
                    ForEach(childTasks) { child in
                        taskTree(task: child, tasks: tasks, depth: depth + 1)
                    }
                }
            }
        )
    }

    private func taskRow(_ task: TaskItem, depth: Int) -> some View {
        HStack(spacing: 0) {
            Color.clear.frame(width: CGFloat(depth) * 16)

            HStack(spacing: 8) {
                leadingTaskControl(for: task)

                if editingTaskID == task.id && !isDeleteMode {
                    HStack(spacing: 6) {
                        TextField("Task", text: $editingTaskText)
                            .font(.system(size: 13, weight: .regular))
                            .foregroundStyle(.primary)
                            .textFieldStyle(.plain)
                            .frame(maxWidth: .infinity, alignment: .leading)

                        smallEditButtons(
                            saveAction: {
                                store.updateTask(id: task.id, title: editingTaskText, category: task.category)
                                editingTaskID = nil
                                editingTaskText = ""
                            },
                            cancelAction: {
                                editingTaskID = nil
                                editingTaskText = ""
                            }
                        )
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                } else {
                    scrollingTaskTitle(task)
                }

                taskAccessoryButton(for: task)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .frame(height: 32)
        .padding(.leading, 14)
        .padding(.trailing, 4)
        .background(
            RoundedRectangle(cornerRadius: 4, style: .continuous)
                .fill(.white.opacity(hoveredTaskID == task.id ? 0.04 : 0))
        )
        .contentShape(Rectangle())
        .animation(.easeInOut(duration: 0.24), value: hoveredTaskID == task.id)
        .onHover { isHovering in
            if isHovering {
                hoveredTaskID = task.id
            } else if hoveredTaskID == task.id {
                hoveredTaskID = nil
            }
        }
    }

    private func scrollingTaskTitle(_ task: TaskItem) -> some View {
        AutoScrollingText(
            text: task.title,
            font: .system(size: 13, weight: .regular),
            enabled: store.preferences.marqueeLongTaskTitles
        )
        .foregroundStyle(.primary)
        .strikethrough(task.isCompleted, color: .primary)
        .frame(maxWidth: .infinity, alignment: .leading)
        .clipped()
        .contentShape(Rectangle())
        .onTapGesture {
            guard !isDeleteMode else { return }
            editingTaskID = task.id
            editingTaskText = task.title
        }
    }

    @ViewBuilder
    private func leadingTaskControl(for task: TaskItem) -> some View {
        if isDeleteMode {
            Button {
                if selectedTaskIDs.contains(task.id) {
                    selectedTaskIDs.remove(task.id)
                } else {
                    selectedTaskIDs.insert(task.id)
                }
            } label: {
                ZStack {
                    RoundedRectangle(cornerRadius: 4, style: .continuous)
                        .fill(selectedTaskIDs.contains(task.id) ? Color.red.opacity(0.8) : Color.black.opacity(0.18))
                    if selectedTaskIDs.contains(task.id) {
                        Image(systemName: "checkmark")
                            .font(.system(size: 10, weight: .bold))
                            .foregroundStyle(.white)
                    }
                }
                .frame(width: 16, height: 16)
            }
            .buttonStyle(.plain)
        } else {
            Button {
                store.toggleTaskCompletion(id: task.id, isCompleted: !task.isCompleted)
            } label: {
                if task.isCompleted {
                    ZStack {
                        Circle().fill(completedCheckboxColor)
                        Rectangle()
                            .fill(.white)
                            .frame(width: 6.5, height: 2)
                            .clipShape(Capsule())
                    }
                    .frame(width: 16, height: 16)
                } else {
                    Circle()
                        .fill(uncheckedCheckboxColor)
                        .frame(width: 16, height: 16)
                }
            }
            .buttonStyle(.plain)
        }
    }

    @ViewBuilder
    private func taskAccessoryButton(for task: TaskItem) -> some View {
        let hasChildren = store.tasks.contains(where: { $0.parentTaskID == task.id })
        let showPlus = (hoveredTaskID == task.id || addingSubtaskParentID == task.id) && !isDeleteMode
        let isPinned = store.preferences.pinnedMenuBarTaskID == task.id

        HStack(spacing: 4) {
            Button {
                guard !isDeleteMode else { return }
                store.setPinnedMenuBarTask(id: isPinned ? nil : task.id)
            } label: {
                Image(systemName: isPinned ? "pin.fill" : "pin")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(isPinned ? store.preferences.tintColor : .white.opacity(0.78))
                    .frame(width: 14, height: 14)
            }
            .buttonStyle(.plain)
            .frame(width: 18, height: 18)
            .opacity((hoveredTaskID == task.id || isPinned) && !isDeleteMode ? 1 : 0)
            .animation(.easeInOut(duration: 0.20), value: hoveredTaskID == task.id)

            if hasChildren {
                Button {
                    guard !isDeleteMode else { return }
                    addingSubtaskParentID = task.id
                    addingSubtaskText = ""
                } label: {
                    Image(systemName: "plus")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundStyle(.white.opacity(0.85))
                        .frame(width: 14, height: 14)
                }
                .buttonStyle(.plain)
                .frame(width: 18, height: 18)
                .opacity(showPlus ? 1 : 0)
                .offset(x: showPlus ? 0 : 2)
                .scaleEffect(showPlus ? 1 : 0.96)
                .animation(.easeInOut(duration: 0.24), value: hoveredTaskID == task.id)
                .animation(.easeInOut(duration: 0.24), value: addingSubtaskParentID == task.id)

                Button {
                    if expandedTaskIDs.contains(task.id) {
                        expandedTaskIDs.remove(task.id)
                    } else {
                        expandedTaskIDs.insert(task.id)
                    }
                } label: {
                    Image(systemName: expandedTaskIDs.contains(task.id) ? "chevron.up" : "chevron.down")
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundStyle(.white.opacity(0.82))
                        .frame(width: 14, height: 14)
                }
                .buttonStyle(.plain)
                .frame(width: 18, height: 18)
                .scaleEffect(hoveredTaskID == task.id ? 1 : 0.96)
                .animation(.easeInOut(duration: 0.24), value: hoveredTaskID == task.id)
            } else {
                Button {
                    guard !isDeleteMode else { return }
                    addingSubtaskParentID = task.id
                    addingSubtaskText = ""
                } label: {
                    Image(systemName: "plus")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundStyle(.white.opacity(0.85))
                        .frame(width: 14, height: 14)
                }
                .buttonStyle(.plain)
                .frame(width: 18, height: 18)
                .opacity(showPlus ? 1 : 0)
                .offset(x: showPlus ? 0 : 2)
                .scaleEffect(showPlus ? 1 : 0.96)
                .animation(.easeInOut(duration: 0.24), value: hoveredTaskID == task.id)
                .animation(.easeInOut(duration: 0.24), value: addingSubtaskParentID == task.id)
            }
        }
        .frame(width: hasChildren ? 60 : 40, alignment: .trailing)
    }

    private func subtaskInputRow(parentTaskID: UUID, depth: Int) -> some View {
        HStack(spacing: 0) {
            Color.clear.frame(width: CGFloat(depth) * 16)

            HStack(spacing: 6) {
                Image(systemName: "arrow.turn.down.right")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(.secondary)

                TextField("New subtask", text: $addingSubtaskText)
                    .font(.system(size: 13, weight: .regular))
                    .foregroundStyle(.primary)
                    .textFieldStyle(.plain)
                    .onSubmit {
                        commitSubtask(parentTaskID: parentTaskID)
                    }

                Spacer(minLength: 0)

                smallEditButtons(
                    saveAction: { commitSubtask(parentTaskID: parentTaskID) },
                    cancelAction: {
                        addingSubtaskParentID = nil
                        addingSubtaskText = ""
                    }
                )
            }
            .padding(.leading, 8)
            .padding(.trailing, 6)
            .frame(height: 28)
            .background(fieldBackground)
        }
        .padding(.horizontal, 8)
        .padding(.bottom, 4)
    }

    private func commitSubtask(parentTaskID: UUID) {
        store.addSubtask(title: addingSubtaskText, parentTaskID: parentTaskID)
        addingSubtaskParentID = nil
        addingSubtaskText = ""
    }


    private func rootTasks(in tasks: [TaskItem]) -> [TaskItem] {
        let ids = Set(tasks.map(\.id))
        return tasks.filter { task in
            guard let parentTaskID = task.parentTaskID else { return true }
            return !ids.contains(parentTaskID)
        }
    }

    private func children(of task: TaskItem, in tasks: [TaskItem]) -> [TaskItem] {
        tasks.filter { $0.parentTaskID == task.id }
    }

    private func normalizedStatisticsRange(from range: ClosedRange<Date>) -> ClosedRange<Date> {
        let calendar = Calendar.current
        let start = calendar.startOfDay(for: min(range.lowerBound, range.upperBound))
        let endDay = calendar.startOfDay(for: max(range.lowerBound, range.upperBound))
        let end = calendar.date(byAdding: .day, value: 1, to: endDay)?.addingTimeInterval(-1) ?? endDay
        return start...end
    }

    private func activeDisplayTasks(in tasks: [TaskItem]) -> [TaskItem] {
        tasks.filter { task in
            !(topLevelAncestor(of: task, in: tasks)?.isCompleted ?? task.isCompleted)
        }
    }

    private func archivedDisplayTasks(in tasks: [TaskItem]) -> [TaskItem] {
        tasks.filter { task in
            topLevelAncestor(of: task, in: tasks)?.isCompleted ?? task.isCompleted
        }
    }

    private func topLevelAncestor(of task: TaskItem, in tasks: [TaskItem]) -> TaskItem? {
        var current = task
        let lookup = Dictionary(uniqueKeysWithValues: tasks.map { ($0.id, $0) })

        while let parentID = current.parentTaskID, let parent = lookup[parentID] {
            current = parent
        }

        return lookup[current.id] ?? current
    }

    private func smallEditButtons(saveAction: @escaping () -> Void, cancelAction: @escaping () -> Void) -> some View {
        HStack(spacing: 4) {
            Button(action: cancelAction) {
                Image(systemName: "xmark")
                    .font(.system(size: 9, weight: .bold))
                    .frame(width: 16, height: 16)
            }
            .buttonStyle(.plain)
            .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 4, style: .continuous))

            Button(action: saveAction) {
                Image(systemName: "checkmark")
                    .font(.system(size: 9, weight: .bold))
                    .frame(width: 16, height: 16)
            }
            .buttonStyle(.plain)
            .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 4, style: .continuous))
        }
        .foregroundStyle(.white.opacity(0.9))
    }

    private func categoryLabel(for category: String?) -> String {
        let cleaned = category?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return cleaned.isEmpty ? "General" : cleaned
    }

    private var notesView: some View {
        VStack(alignment: .leading, spacing: 8) {
            nextEventBanner

            Button {
                noteEditor.open(note: nil, preferences: store.preferences, onSave: store.upsertNote)
            } label: {
                HStack {
                    Text("Take a new note")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(.black)
                    Spacer(minLength: 0)
                }
                .frame(maxWidth: .infinity)
                .padding(.leading, 8)
                .padding(.trailing, 4)
                .frame(height: 28)
                .background(Color.white.opacity(0.94), in: RoundedRectangle(cornerRadius: 7, style: .continuous))
            }
            .buttonStyle(.plain)

            if store.notes.isEmpty {
                ContentUnavailableView("No notes", systemImage: "note.text")
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                ScrollView(showsIndicators: false) {
                    LazyVStack(spacing: 8) {
                        ForEach(store.notes) { note in
                            noteRow(note)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .topLeading)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
            }
        }
    }

    private func noteRow(_ note: NoteItem) -> some View {
        HStack(spacing: 8) {
            Text(note.content)
                .font(.system(size: 14, weight: .regular))
                .foregroundStyle(.primary)
                .lineLimit(2)
                .multilineTextAlignment(.leading)
                .lineSpacing(2)
                .contentShape(Rectangle())
                .onTapGesture {
                    noteEditor.open(note: note, preferences: store.preferences, onSave: store.upsertNote)
                }

            Spacer(minLength: 0)

            Button(role: .destructive) {
                store.deleteNote(id: note.id)
            } label: {
                Image(systemName: "trash")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(.red.opacity(0.9))
                    .frame(width: 18, height: 18)
            }
            .buttonStyle(.plain)
        }
        .padding(8)
        .frame(minHeight: 64)
        .background(cardBackground)
    }

    private var cardBackground: some View {
        RoundedRectangle(cornerRadius: 8, style: .continuous)
            .fill(.ultraThinMaterial)
            .overlay(
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .strokeBorder(.white.opacity(0.12), lineWidth: 1)
            )
    }

    private var fieldBackground: some View {
        RoundedRectangle(cornerRadius: 7, style: .continuous)
            .fill(.ultraThinMaterial)
            .overlay(
                RoundedRectangle(cornerRadius: 7, style: .continuous)
                    .strokeBorder(.white.opacity(0.12), lineWidth: 1)
            )
    }

    private func applyLaunchAtLogin(_ enabled: Bool) {
        #if canImport(ServiceManagement)
        do {
            if enabled {
                try SMAppService.mainApp.register()
            } else {
                try SMAppService.mainApp.unregister()
            }
        } catch {
            // Persist the setting even if registration fails in a non-bundled debug run.
        }
        #endif
        store.setLaunchAtLogin(enabled)
    }

    private func exportTasks() {
        guard let url = showSavePanel(suggestedName: "tasks") else { return }
        do {
            try store.exportTasks(to: url)
        } catch {
            presentFileError(title: "Couldn’t export tasks", error: error)
        }
    }

    private func importTasks() {
        guard let url = showOpenPanel() else { return }
        do {
            try store.importTasks(from: url)
        } catch {
            presentFileError(title: "Couldn’t load tasks", error: error)
        }
    }

    private func exportNotes() {
        guard let url = showSavePanel(suggestedName: "notes") else { return }
        do {
            try store.exportNotes(to: url)
        } catch {
            presentFileError(title: "Couldn’t export notes", error: error)
        }
    }

    private func importNotes() {
        guard let url = showOpenPanel() else { return }
        do {
            try store.importNotes(from: url)
        } catch {
            presentFileError(title: "Couldn’t load notes", error: error)
        }
    }

    private func openBackupLocation() {
        try? FileManager.default.createDirectory(at: store.backupDirectory, withIntermediateDirectories: true)
        NSWorkspace.shared.open(store.backupDirectory)
    }

    private func showSavePanel(suggestedName: String) -> URL? {
        let panel = NSSavePanel()
        panel.allowedContentTypes = [UTType.json]
        panel.nameFieldStringValue = "\(suggestedName).json"
        panel.canCreateDirectories = true
        return panel.runModal() == .OK ? panel.url : nil
    }

    private func showOpenPanel() -> URL? {
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = false
        panel.canChooseDirectories = false
        panel.allowedContentTypes = [UTType.json]
        return panel.runModal() == .OK ? panel.url : nil
    }

    private func presentFileError(title: String, error: Error) {
        let alert = NSAlert()
        alert.alertStyle = .warning
        alert.messageText = title
        alert.informativeText = error.localizedDescription
        alert.addButton(withTitle: "OK")
        alert.runModal()
    }

    private var positiveTintColor: Color {
        store.preferences.tintStyle == .graphite ? .green : store.preferences.tintColor
    }

    private var remainingTintColor: Color {
        store.preferences.tintStyle == .graphite ? .blue : store.preferences.tintColor
    }

    private var completedCheckboxColor: Color {
        store.preferences.tintStyle == .graphite ? Color.black.opacity(0.9) : store.preferences.tintColor
    }

    private var uncheckedCheckboxColor: Color {
        store.preferences.tintStyle == .graphite ? Color.black.opacity(0.22) : store.preferences.tintColor.opacity(0.22)
    }
}

private struct TaskCategoryGroup: Identifiable {
    let id: String
    let title: String
    let category: AppCategory?
    let tasks: [TaskItem]

    var isEditable: Bool { title != "General" }
}

private struct ChipScrollMinXPreferenceKey: PreferenceKey {
    static var defaultValue: CGFloat = 0

    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
        value = nextValue()
    }
}

private struct ChipScrollContentWidthPreferenceKey: PreferenceKey {
    static var defaultValue: CGFloat = 0

    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
        value = nextValue()
    }
}

private struct CategoryFramePreferenceKey: PreferenceKey {
    static var defaultValue: [String: CGRect] = [:]

    static func reduce(value: inout [String: CGRect], nextValue: () -> [String: CGRect]) {
        value.merge(nextValue(), uniquingKeysWith: { _, new in new })
    }
}

private struct ReorderViewportPreferenceKey: PreferenceKey {
    static var defaultValue: CGRect = .zero

    static func reduce(value: inout CGRect, nextValue: () -> CGRect) {
        value = nextValue()
    }
}

private struct TaskListContentPreferenceKey: PreferenceKey {
    static var defaultValue: CGRect = .zero

    static func reduce(value: inout CGRect, nextValue: () -> CGRect) {
        value = nextValue()
    }
}

private struct CategoryIconView: View {
    let iconSystemName: String
    let iconEmoji: String?
    let iconFilePath: String?

    var body: some View {
        Group {
            if let iconEmoji, !iconEmoji.isEmpty {
                Text(iconEmoji)
                    .font(.system(size: 14))
            } else if let iconFilePath,
                      let image = NSImage(contentsOfFile: iconFilePath) {
                Image(nsImage: image)
                    .resizable()
                    .scaledToFit()
            } else {
                Image(systemName: iconSystemName)
                    .resizable()
                    .scaledToFit()
                    .foregroundStyle(.white.opacity(0.9))
                    .padding(2)
            }
        }
        .frame(width: 14, height: 14)
    }
}

private struct SettingsPopoverView: View {
    let preferences: AppPreferences
    let backupLocation: String
    let onIconSelected: (String) -> Void
    let onTintSelected: (AppTintStyle) -> Void
    let onCustomTintSelected: (String) -> Void
    let onLaunchAtLoginChanged: (Bool) -> Void
    let onMarqueeChanged: (Bool) -> Void
    let onAutoBackupFrequencyChanged: (AutoBackupFrequency) -> Void
    let onCalendarTargetChanged: (CalendarNewEventTarget) -> Void
    let onShowPinnedTaskChanged: (Bool) -> Void
    let onRequestCalendarAccess: () -> Void
    let onOpenCalendarSettings: () -> Void
    let onOpenBackupLocation: () -> Void
    let onExportTasks: () -> Void
    let onImportTasks: () -> Void
    let onExportNotes: () -> Void
    let onImportNotes: () -> Void
    let onQuit: () -> Void

    @State private var selectedTab: SettingsWindowTab = .general
    @State private var selectedIcon: String?
    @State private var selectedTint: AppTintStyle?
    @State private var selectedCustomTintColor: Color?
    @State private var selectedAutoBackupFrequency: AutoBackupFrequency?
    @State private var selectedCalendarTarget: CalendarNewEventTarget?
    @State private var launchAtLogin: Bool?
    @State private var marqueeLongTaskTitles: Bool?
    @State private var showPinnedTaskInMenuBar: Bool?
    @State private var hoveredID: String?
    @State private var isCustomTintPopoverPresented = false

    private let menuIcons = [
        "checklist.checked",
        "checkmark.circle",
        "square.and.pencil",
        "list.bullet.rectangle",
        "note.text",
        "tray.full",
        MenuBarIconAsset.taskly
    ]

    var body: some View {
        VStack(spacing: 0) {
            header

            Divider()
                .opacity(0.35)

            activeTabContent
                .padding(16)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        }
        .frame(width: 380, height: preferredHeight)
        .background(Color.clear)
        .fontDesign(.rounded)
        .animation(.easeInOut(duration: 0.18), value: selectedTab)
    }

    private var preferredHeight: CGFloat {
        switch selectedTab {
        case .general: return 292
        case .appearance: return 304
        case .backup: return 430
        case .calendar: return 342
        }
    }

    private var header: some View {
        VStack(spacing: 14) {
            Text(selectedTab.title)
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(.secondary)

            HStack(spacing: 14) {
                ForEach(SettingsWindowTab.allCases) { tab in
                    Button {
                        selectedTab = tab
                    } label: {
                        VStack(spacing: 5) {
                            Image(systemName: tab.systemImage)
                                .font(.system(size: 22, weight: .medium))
                            Text(tab.title)
                                .font(.system(size: 12, weight: .medium))
                        }
                        .foregroundStyle(selectedTab == tab ? Color.blue : .secondary)
                        .frame(width: 72, height: 64)
                    }
                    .buttonStyle(SettingsWindowTabButtonStyle(isSelected: selectedTab == tab))
                }
            }
        }
        .padding(.top, 12)
        .padding(.bottom, 14)
    }

    @ViewBuilder
    private var activeTabContent: some View {
        switch selectedTab {
        case .general:
            generalTab
        case .appearance:
            appearanceTab
        case .backup:
            backupTab
        case .calendar:
            calendarTab
        }
    }

    private var generalTab: some View {
        settingsGroup {
            settingsToggleRow("Launch at login", isOn: launchAtLoginBinding)
            groupDivider
            settingsToggleRow("Show current task in menu bar", isOn: showPinnedTaskBinding)
            groupDivider
            settingsToggleRow("Scroll long task titles", isOn: marqueeLongTaskTitlesBinding)
        }
    }

    private var appearanceTab: some View {
        VStack(alignment: .leading, spacing: 24) {
            VStack(alignment: .leading, spacing: 12) {
                sectionTitle("Menu bar icon")
                HStack(spacing: 12) {
                    ForEach(menuIcons, id: \.self) { icon in
                        iconButton(icon)
                    }
                }
            }

            VStack(alignment: .leading, spacing: 12) {
                sectionTitle("App tint")
                HStack(spacing: 12) {
                    ForEach(AppTintStyle.presetCases) { tint in
                        tintButton(tint)
                    }
                    customTintButton
                }
            }
        }
    }

    private var backupTab: some View {
        VStack(alignment: .leading, spacing: 24) {
            VStack(alignment: .leading, spacing: 12) {
                sectionTitle("Auto Backup")
                HStack(spacing: 8) {
                    ForEach(AutoBackupFrequency.allCases) { frequency in
                        backupFrequencyButton(frequency)
                    }
                }
            }

            settingsGroup {
                settingsActionRow("Backup location", value: shortenedBackupLocation, systemImage: "folder", action: onOpenBackupLocation)
                groupDivider
                settingsActionRow("Export current tasks", systemImage: "square.and.arrow.up", action: onExportTasks)
                groupDivider
                settingsActionRow("Load tasks", systemImage: "square.and.arrow.down", action: onImportTasks)
                groupDivider
                settingsActionRow("Export current notes", systemImage: "square.and.arrow.up", action: onExportNotes)
                groupDivider
                settingsActionRow("Load notes", systemImage: "square.and.arrow.down", action: onImportNotes)
            }
        }
    }

    private var calendarTab: some View {
        VStack(alignment: .leading, spacing: 24) {
            VStack(alignment: .leading, spacing: 12) {
                sectionTitle("New event opens in")
                HStack(spacing: 8) {
                    ForEach(CalendarNewEventTarget.allCases) { target in
                        calendarTargetButton(target)
                    }
                }
            }

            settingsGroup {
                settingsActionRow("Allow calendar access", systemImage: "calendar.badge.checkmark", action: onRequestCalendarAccess)
                groupDivider
                settingsActionRow("Open calendar accounts", systemImage: "gearshape", action: onOpenCalendarSettings)
                groupDivider
                settingsActionRow("Quit app", systemImage: "power", action: onQuit)
            }
        }
    }

    private func settingsGroup<Content: View>(@ViewBuilder content: () -> Content) -> some View {
        VStack(spacing: 0) {
            content()
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 8)
        .background(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(.ultraThinMaterial)
        )
    }

    private func sectionTitle(_ title: String) -> some View {
        Text(title)
            .font(.system(size: 13, weight: .semibold))
            .foregroundStyle(.white.opacity(0.92))
    }

    private var groupDivider: some View {
        Divider()
            .opacity(0.35)
            .padding(.leading, 0)
    }

    private func settingsToggleRow(_ title: String, isOn: Binding<Bool>) -> some View {
        HStack {
            Text(title)
                .font(.system(size: 13, weight: .medium))
            Spacer(minLength: 12)
            Toggle("", isOn: isOn)
                .toggleStyle(.switch)
                .labelsHidden()
        }
        .frame(height: 38)
    }

    private func settingsActionRow(_ title: String, value: String? = nil, systemImage: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 10) {
                Image(systemName: systemImage)
                    .font(.system(size: 13, weight: .semibold))
                    .frame(width: 18)
                Text(title)
                    .font(.system(size: 13, weight: .medium))
                Spacer(minLength: 8)
                if let value {
                    Text(value)
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                Image(systemName: "chevron.right")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(.secondary)
            }
            .frame(height: 38)
            .padding(.horizontal, 6)
            .background(
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .fill(hoveredID == title ? Color.white.opacity(0.06) : Color.clear)
            )
        }
        .buttonStyle(.plain)
        .onHover { hoveredID = $0 ? title : nil }
    }

    private func iconButton(_ icon: String) -> some View {
        let isSelected = currentIcon == icon
        return Button {
            selectedIcon = icon
            onIconSelected(icon)
        } label: {
            MenuBarIconGlyph(identifier: icon)
                .foregroundStyle(isSelected ? .white : .white.opacity(0.72))
                .frame(width: 17, height: 17)
                .frame(width: 38, height: 38)
        }
        .buttonStyle(SettingsIconButtonStyle(isSelected: isSelected, isHovered: hoveredID == icon))
        .onHover { hoveredID = $0 ? icon : nil }
    }

    private func tintButton(_ tint: AppTintStyle) -> some View {
        let isSelected = currentTint == tint
        return Button {
            selectedTint = tint
            onTintSelected(tint)
        } label: {
            Circle()
                .fill(tint.color)
                .frame(width: 22, height: 22)
                .overlay(
                    Circle()
                        .strokeBorder(.white.opacity(isSelected ? 0.64 : 0.20), lineWidth: isSelected ? 2 : 1)
                )
                .frame(width: 38, height: 38)
        }
        .buttonStyle(.plain)
        .background(
            RoundedRectangle(cornerRadius: 10, style: .continuous)
                .fill(hoveredID == tint.rawValue ? Color.white.opacity(0.06) : Color.clear)
        )
        .onHover { hoveredID = $0 ? tint.rawValue : nil }
    }

    private var customTintButton: some View {
        Button {
            isCustomTintPopoverPresented.toggle()
        } label: {
            Circle()
                .fill(
                    AngularGradient(
                        gradient: Gradient(colors: [.red, .orange, .yellow, .green, .cyan, .blue, .purple, .pink, .red]),
                        center: .center
                    )
                )
                .frame(width: 22, height: 22)
                .overlay(
                    Circle()
                        .fill(currentTint == .custom ? currentCustomTintColor : .clear)
                        .padding(5)
                )
                .overlay(
                    Circle()
                        .strokeBorder(.white.opacity(currentTint == .custom ? 0.64 : 0.22), lineWidth: currentTint == .custom ? 2 : 1)
                )
                .frame(width: 38, height: 38)
        }
        .buttonStyle(.plain)
        .background(
            RoundedRectangle(cornerRadius: 10, style: .continuous)
                .fill(hoveredID == "customTint" ? Color.white.opacity(0.06) : Color.clear)
        )
        .onHover { hoveredID = $0 ? "customTint" : nil }
        .popover(isPresented: $isCustomTintPopoverPresented, attachmentAnchor: .point(.bottom), arrowEdge: .top) {
            CustomTintPaletteView(
                selected: currentCustomTintColor,
                onPick: { color in
                    if let hex = color.hexString {
                        selectedTint = .custom
                        selectedCustomTintColor = color
                        onCustomTintSelected(hex)
                    }
                    isCustomTintPopoverPresented = false
                }
            )
            .presentationBackground(.ultraThickMaterial)
        }
    }

    private func backupFrequencyButton(_ frequency: AutoBackupFrequency) -> some View {
        let isSelected = currentAutoBackupFrequency == frequency
        return Button {
            selectedAutoBackupFrequency = frequency
            onAutoBackupFrequencyChanged(frequency)
        } label: {
            Text(frequency.title)
                .font(.system(size: 12, weight: .semibold))
                .frame(minWidth: 58)
                .frame(height: 32)
        }
        .buttonStyle(SettingsPillButtonStyle(isSelected: isSelected, isHovered: hoveredID == frequency.rawValue))
        .onHover { hoveredID = $0 ? frequency.rawValue : nil }
    }

    private func calendarTargetButton(_ target: CalendarNewEventTarget) -> some View {
        let isSelected = currentCalendarTarget == target
        return Button {
            selectedCalendarTarget = target
            onCalendarTargetChanged(target)
        } label: {
            Text(target.shortTitle)
                .font(.system(size: 12, weight: .semibold))
                .frame(minWidth: 74)
                .frame(height: 32)
        }
        .buttonStyle(SettingsPillButtonStyle(isSelected: isSelected, isHovered: hoveredID == target.rawValue))
        .onHover { hoveredID = $0 ? target.rawValue : nil }
    }

    private var currentIcon: String {
        selectedIcon ?? preferences.menuBarIconSystemName
    }

    private var currentTint: AppTintStyle {
        selectedTint ?? preferences.tintStyle
    }

    private var currentCustomTintColor: Color {
        selectedCustomTintColor ?? preferences.customTintColor
    }

    private var currentAutoBackupFrequency: AutoBackupFrequency {
        selectedAutoBackupFrequency ?? preferences.autoBackupFrequency
    }

    private var currentCalendarTarget: CalendarNewEventTarget {
        selectedCalendarTarget ?? preferences.calendarNewEventTarget
    }

    private var shortenedBackupLocation: String {
        let url = URL(fileURLWithPath: backupLocation)
        return ".../" + url.deletingLastPathComponent().lastPathComponent + "/" + url.lastPathComponent
    }

    private var launchAtLoginBinding: Binding<Bool> {
        Binding(
            get: { launchAtLogin ?? preferences.launchAtLogin },
            set: {
                launchAtLogin = $0
                onLaunchAtLoginChanged($0)
            }
        )
    }

    private var marqueeLongTaskTitlesBinding: Binding<Bool> {
        Binding(
            get: { marqueeLongTaskTitles ?? preferences.marqueeLongTaskTitles },
            set: {
                marqueeLongTaskTitles = $0
                onMarqueeChanged($0)
            }
        )
    }

    private var showPinnedTaskBinding: Binding<Bool> {
        Binding(
            get: { showPinnedTaskInMenuBar ?? preferences.showPinnedTaskInMenuBar },
            set: {
                showPinnedTaskInMenuBar = $0
                onShowPinnedTaskChanged($0)
            }
        )
    }
}

private enum SettingsWindowTab: String, CaseIterable, Identifiable {
    case general
    case appearance
    case backup
    case calendar

    var id: String { rawValue }

    var title: String {
        switch self {
        case .general: return "General"
        case .appearance: return "Appearance"
        case .backup: return "Backup"
        case .calendar: return "Calendars"
        }
    }

    var systemImage: String {
        switch self {
        case .general: return "gearshape"
        case .appearance: return "paintbrush"
        case .backup: return "externaldrive"
        case .calendar: return "calendar"
        }
    }
}

private struct SettingsWindowTabButtonStyle: ButtonStyle {
    let isSelected: Bool

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .background(
                RoundedRectangle(cornerRadius: 10, style: .continuous)
                    .fill(isSelected ? Color.white.opacity(0.06) : Color.clear)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 10, style: .continuous)
                    .strokeBorder(.white.opacity(isSelected ? 0.16 : 0), lineWidth: 1)
            )
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
            .animation(.easeInOut(duration: 0.14), value: configuration.isPressed)
            .animation(.easeInOut(duration: 0.16), value: isSelected)
    }
}

private struct SettingsIconButtonStyle: ButtonStyle {
    let isSelected: Bool
    let isHovered: Bool

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .background(
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .fill(backgroundStyle(isPressed: configuration.isPressed))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .strokeBorder(.white.opacity(isSelected ? 0.64 : 0.10), lineWidth: 1)
            )
            .scaleEffect(configuration.isPressed ? 0.96 : 1)
            .animation(.easeInOut(duration: 0.14), value: configuration.isPressed)
            .animation(.easeInOut(duration: 0.16), value: isSelected)
            .animation(.easeInOut(duration: 0.16), value: isHovered)
    }

    private func backgroundStyle(isPressed: Bool) -> AnyShapeStyle {
        if isSelected {
            return AnyShapeStyle(Color.white.opacity(0.08))
        }
        if isHovered {
            return AnyShapeStyle(Color.white.opacity(0.08))
        }
        if isPressed {
            return AnyShapeStyle(Color.white.opacity(0.08))
        }
        return AnyShapeStyle(Color.white.opacity(0.03))
    }
}

private struct SettingsPillButtonStyle: ButtonStyle {
    let isSelected: Bool
    let isHovered: Bool

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .background(
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .fill(backgroundStyle(isPressed: configuration.isPressed))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .strokeBorder(.white.opacity(isSelected ? 0.64 : 0.12), lineWidth: 1)
            )
            .scaleEffect(configuration.isPressed ? 0.98 : 1)
            .animation(.easeInOut(duration: 0.14), value: configuration.isPressed)
            .animation(.easeInOut(duration: 0.14), value: isHovered)
            .animation(.easeInOut(duration: 0.14), value: isSelected)
    }

    private func backgroundStyle(isPressed: Bool) -> AnyShapeStyle {
        if isSelected {
            return AnyShapeStyle(Color.white.opacity(0.08))
        }
        if isHovered || isPressed {
            return AnyShapeStyle(Color.white.opacity(0.08))
        }
        return AnyShapeStyle(Color.clear)
    }
}

private struct AutoScrollingText: View {
    let text: String
    let font: Font
    let enabled: Bool

    @State private var textWidth: CGFloat = 0
    @State private var containerWidth: CGFloat = 0
    @State private var offset: CGFloat = 0
    @State private var animationTask: Task<Void, Never>?

    private let gap: CGFloat = 28
    private let pointsPerSecond: CGFloat = 22

    var body: some View {
        GeometryReader { proxy in
            Group {
                if shouldScroll {
                    HStack(spacing: gap) {
                        textLabel
                        textLabel
                    }
                    .offset(x: offset)
                    .clipped()
                } else {
                    textLabel
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
            .mask(
                Group {
                    if shouldScroll {
                        marqueeFadeMask
                    } else {
                        Rectangle()
                    }
                }
            )
            .onAppear {
                containerWidth = proxy.size.width
                restartAnimationIfNeeded()
            }
            .onChange(of: proxy.size.width) { _, newValue in
                let wasScrolling = shouldScroll
                containerWidth = newValue
                let isScrolling = enabled && textWidth > newValue && newValue > 0
                if wasScrolling != isScrolling {
                    restartAnimationIfNeeded()
                }
            }
            .onChange(of: text) { _, _ in
                restartAnimationIfNeeded()
            }
            .onChange(of: enabled) { _, _ in
                restartAnimationIfNeeded()
            }
        }
        .frame(height: 18)
        .onDisappear {
            animationTask?.cancel()
            animationTask = nil
        }
    }

    private var marqueeFadeMask: some View {
        GeometryReader { proxy in
            ZStack {
                Rectangle().fill(.white)

                LinearGradient(
                    colors: [.white.opacity(leftFadeStrength), .white],
                    startPoint: .leading,
                    endPoint: .trailing
                )
                .frame(width: fadeWidth)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)

                LinearGradient(
                    colors: [.white, .clear],
                    startPoint: .leading,
                    endPoint: .trailing
                )
                .frame(width: fadeWidth)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .trailing)
            }
            .frame(width: proxy.size.width, height: proxy.size.height)
        }
    }

    private var textLabel: some View {
        Text(text)
            .font(font)
            .lineLimit(1)
            .fixedSize(horizontal: true, vertical: false)
            .background(
                GeometryReader { proxy in
                    Color.clear
                        .onAppear { textWidth = proxy.size.width }
                        .onChange(of: proxy.size.width) { _, newValue in
                            textWidth = newValue
                            restartAnimationIfNeeded()
                        }
                }
            )
    }

    private var shouldScroll: Bool {
        enabled && textWidth > containerWidth && containerWidth > 0
    }

    private var leftFadeStrength: CGFloat {
        guard shouldScroll else { return 0 }
        let progress = min(max((-offset) / 22, 0), 1)
        return progress * progress
    }

    private var fadeWidth: CGFloat { 18 }

    private func restartAnimationIfNeeded() {
        animationTask?.cancel()
        animationTask = nil
        offset = 0

        guard shouldScroll else { return }

        let distance = textWidth + gap
        let duration = distance / pointsPerSecond

        animationTask = Task {
            while !Task.isCancelled {
                try? await Task.sleep(for: .seconds(0.8))
                guard !Task.isCancelled else { break }
                await MainActor.run {
                    withAnimation(.linear(duration: duration)) {
                        offset = -distance
                    }
                }
                try? await Task.sleep(for: .seconds(duration))
                guard !Task.isCancelled else { break }
                await MainActor.run {
                    offset = 0
                }
                try? await Task.sleep(for: .seconds(0.8))
            }
        }
    }
}

private struct CustomTintPaletteView: View {
    let selected: Color
    let onPick: (Color) -> Void

    private let palette: [Color] = [
        .white.opacity(0.16),
        Color(red: 0.20, green: 0.52, blue: 1.0),
        Color(red: 0.22, green: 0.72, blue: 0.44),
        Color(red: 0.96, green: 0.66, blue: 0.18),
        Color(red: 1.0, green: 0.34, blue: 0.52),
        .red,
        .orange,
        .yellow,
        .mint,
        .teal,
        .cyan,
        .indigo,
        .purple,
        .brown,
        .gray,
        Color(red: 0.85, green: 0.2, blue: 0.5),
        Color(red: 0.35, green: 0.80, blue: 0.75),
        Color(red: 0.55, green: 0.45, blue: 0.95),
        Color(red: 0.98, green: 0.42, blue: 0.28),
        Color(red: 0.30, green: 0.62, blue: 0.30)
    ]

    private let columns = Array(repeating: GridItem(.fixed(28), spacing: 8), count: 4)

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            RoundedRectangle(cornerRadius: 8, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [.red, .yellow, .green, .cyan, .blue, .purple, .pink],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .frame(height: 18)
                .overlay(
                    RoundedRectangle(cornerRadius: 8, style: .continuous)
                        .strokeBorder(.white.opacity(0.12), lineWidth: 1)
                )

            LazyVGrid(columns: columns, spacing: 8) {
                ForEach(Array(palette.enumerated()), id: \.offset) { _, color in
                    Button {
                        onPick(color)
                    } label: {
                        Circle()
                            .fill(color)
                            .frame(width: 18, height: 18)
                            .overlay(
                                Circle()
                                    .strokeBorder(.white.opacity(0.28), lineWidth: 1)
                            )
                            .frame(width: 28, height: 28)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .padding(10)
        .background(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .fill(.ultraThickMaterial)
        )
    }
}

private struct CategoryIconPaletteView: View {
    let selectedSystemName: String
    let onSelect: (String) -> Void
    @State private var hoveredIcon: String?

    private let icons: [String] = [
        "checklist.checked", "checkmark.circle", "list.bullet.rectangle", "tray.full", "folder",
        "briefcase", "doc.text", "terminal", "pencil.and.ruler", "paintbrush",
        "hammer", "wrench.and.screwdriver", "bolt", "globe", "wifi",
        "person.2", "building.2", "cart", "creditcard", "chart.bar",
        "calendar", "clock", "bookmark", "star", "flag",
        "tag", "book", "graduationcap", "heart", "sparkles"
    ]

    private let columns = Array(repeating: GridItem(.fixed(32), spacing: 8), count: 5)

    var body: some View {
        LazyVGrid(columns: columns, spacing: 8) {
            ForEach(icons, id: \.self) { icon in
                let isSelected = selectedSystemName == icon
                let isHovered = hoveredIcon == icon
                Button {
                    onSelect(icon)
                } label: {
                    Image(systemName: icon)
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(isSelected ? .white : .white.opacity(0.75))
                        .frame(width: 32, height: 32)
                        .background(
                            RoundedRectangle(cornerRadius: 8, style: .continuous)
                                .fill(isSelected ? AnyShapeStyle(Color.white.opacity(0.08)) : AnyShapeStyle(Color.white.opacity(isHovered ? 0.08 : 0.02)))
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 8, style: .continuous)
                                .strokeBorder(.white.opacity(isSelected ? 0.64 : 0.12), lineWidth: 1)
                        )
                }
                .buttonStyle(.plain)
                .onHover { isHovered in
                    hoveredIcon = isHovered ? icon : nil
                }
            }
        }
        .padding(12)
        .frame(width: 216)
        .background(Color.clear)
    }
}

private struct StatisticsRangePickerView: View {
    @Binding var startDate: Date
    @Binding var endDate: Date
    @Binding var selectedMonth: Int
    @Binding var selectedYear: Int
    let availableYears: [Int]
    let onApply: () -> Void
    let onCancel: () -> Void

    private var months: [Int] {
        Array(1...12)
    }

    private var yearChoices: [Int] {
        let currentYear = Calendar.current.component(.year, from: .now)
        return Array(Set(availableYears + [currentYear])).sorted(by: >)
    }

    private var shouldEnableYearSelection: Bool {
        let currentYear = Calendar.current.component(.year, from: .now)
        return yearChoices.contains { $0 < currentYear }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Statistics period")
                .font(.system(size: 12, weight: .semibold))

            VStack(alignment: .leading, spacing: 8) {
                Text("Quick ranges")
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(.secondary)

                LazyVGrid(columns: [GridItem(.flexible(), spacing: 8), GridItem(.flexible(), spacing: 8)], spacing: 8) {
                    presetButton("Today") {
                        let today = Calendar.current.startOfDay(for: .now)
                        startDate = today
                        endDate = today
                        onApply()
                    }
                    presetButton("7 days") {
                        let today = Calendar.current.startOfDay(for: .now)
                        startDate = Calendar.current.date(byAdding: .day, value: -6, to: today) ?? today
                        endDate = today
                        onApply()
                    }
                    presetButton("30 days") {
                        let today = Calendar.current.startOfDay(for: .now)
                        startDate = Calendar.current.date(byAdding: .day, value: -29, to: today) ?? today
                        endDate = today
                        onApply()
                    }
                    presetButton("This month") {
                        let calendar = Calendar.current
                        let today = Calendar.current.startOfDay(for: .now)
                        let monthStart = calendar.date(from: calendar.dateComponents([.year, .month], from: today)) ?? today
                        startDate = monthStart
                        endDate = today
                        onApply()
                    }
                }
            }

            Divider()

            VStack(alignment: .leading, spacing: 8) {
                Text("Month")
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(.secondary)

                HStack(spacing: 8) {
                    Menu {
                        ForEach(months, id: \.self) { month in
                            Button(monthTitle(month)) {
                                selectedMonth = month
                                selectCurrentMonth()
                            }
                        }
                    } label: {
                        menuLabel(monthTitle(selectedMonth), minWidth: 130)
                    }
                    .buttonStyle(.plain)

                    Menu {
                        ForEach(yearChoices, id: \.self) { year in
                            Button(String(year)) {
                                selectedYear = year
                                selectCurrentMonth()
                            }
                        }
                    } label: {
                        menuLabel(String(selectedYear), minWidth: 86)
                            .opacity(shouldEnableYearSelection ? 1 : 0.45)
                    }
                    .buttonStyle(.plain)
                    .disabled(!shouldEnableYearSelection)
                }
            }
        }
        .padding(12)
        .frame(width: 280, height: 216, alignment: .topLeading)
        .background(Color.clear)
    }

    private func selectCurrentMonth() {
        let calendar = Calendar.current
        let components = DateComponents(year: selectedYear, month: selectedMonth, day: 1)
        let start = calendar.date(from: components) ?? calendar.startOfDay(for: .now)
        let end = calendar.date(byAdding: DateComponents(month: 1, day: -1), to: start) ?? start
        startDate = start
        endDate = end
        onApply()
    }

    private func monthTitle(_ month: Int) -> String {
        Calendar.current.monthSymbols[max(0, min(month - 1, 11))]
    }

    private func menuLabel(_ title: String, minWidth: CGFloat) -> some View {
        HStack(spacing: 8) {
            Text(title)
                .font(.system(size: 11, weight: .semibold))
                .lineLimit(1)
            Spacer(minLength: 0)
            Image(systemName: "chevron.up.chevron.down")
                .font(.system(size: 9, weight: .semibold))
                .foregroundStyle(.secondary)
        }
        .padding(.horizontal, 10)
        .frame(minWidth: minWidth)
        .frame(height: 32)
        .background(
            RoundedRectangle(cornerRadius: 8, style: .continuous)
                .fill(.thinMaterial)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 8, style: .continuous)
                .strokeBorder(.white.opacity(0.12), lineWidth: 1)
        )
    }

    private func presetButton(_ title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 11, weight: .medium))
                .frame(maxWidth: .infinity)
                .frame(height: 30)
                .background(
                    RoundedRectangle(cornerRadius: 8, style: .continuous)
                        .fill(.thinMaterial)
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 8, style: .continuous)
                        .strokeBorder(.white.opacity(0.12), lineWidth: 1)
                )
        }
        .buttonStyle(.plain)
    }
}

private enum DropdownPointerAlignment {
    case center
    case trailing
}

private struct DropdownPanelContent<Content: View>: View {
    let width: CGFloat
    let pointerAlignment: DropdownPointerAlignment
    @ViewBuilder let content: Content

    var body: some View {
        VStack(spacing: -7) {
            HStack(spacing: 0) {
                if pointerAlignment == .center {
                    Spacer(minLength: 0)
                    pointer
                    Spacer(minLength: 0)
                } else {
                    Spacer(minLength: 0)
                    pointer
                        .padding(.trailing, 26)
                }
            }
            .frame(width: width)
            .zIndex(1)

            content
                .frame(width: width, alignment: .topLeading)
                .background(PanelGlassSurface(cornerRadius: 14))
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .strokeBorder(.white.opacity(0.10), lineWidth: 1)
                )
        }
        .frame(width: width, alignment: .top)
        .fixedSize(horizontal: false, vertical: true)
    }

    private var pointer: some View {
        RoundedRectangle(cornerRadius: 4, style: .continuous)
            .fill(.clear)
            .frame(width: 18, height: 18)
            .background(PanelGlassSurface(cornerRadius: 4))
            .clipShape(RoundedRectangle(cornerRadius: 4, style: .continuous))
            .rotationEffect(.degrees(45))
            .overlay(
                RoundedRectangle(cornerRadius: 4, style: .continuous)
                    .strokeBorder(.white.opacity(0.10), lineWidth: 1)
                    .rotationEffect(.degrees(45))
            )
    }
}

private enum ProgressiveBlurDirection {
    case blurredTopClearBottom
    case blurredBottomClearTop
}

private struct PanelGlassSurface: NSViewRepresentable {
    let cornerRadius: CGFloat

    func makeNSView(context: Context) -> NSView {
        let container = NSView()
        container.wantsLayer = true

        let background: NSView
        if #available(macOS 26, *) {
            let glass = NSGlassEffectView()
            glass.cornerRadius = cornerRadius
            background = glass
        } else {
            let effect = NSVisualEffectView()
            effect.material = .hudWindow
            effect.blendingMode = .withinWindow
            effect.state = .active
            effect.wantsLayer = true
            effect.layer?.cornerRadius = cornerRadius
            effect.layer?.masksToBounds = true
            background = effect
        }

        background.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(background)
        NSLayoutConstraint.activate([
            background.leadingAnchor.constraint(equalTo: container.leadingAnchor),
            background.trailingAnchor.constraint(equalTo: container.trailingAnchor),
            background.topAnchor.constraint(equalTo: container.topAnchor),
            background.bottomAnchor.constraint(equalTo: container.bottomAnchor)
        ])
        return container
    }

    func updateNSView(_ nsView: NSView, context: Context) {}
}

private struct ProgressiveBlurView: NSViewRepresentable {
    var maxBlurRadius: CGFloat = 18
    var direction: ProgressiveBlurDirection = .blurredBottomClearTop
    var startOffset: CGFloat = 0

    func makeNSView(context: Context) -> VariableBlurNSVisualEffectView {
        VariableBlurNSVisualEffectView(
            maxBlurRadius: maxBlurRadius,
            direction: direction,
            startOffset: startOffset
        )
    }

    func updateNSView(_ nsView: VariableBlurNSVisualEffectView, context: Context) {
        nsView.update(maxBlurRadius: maxBlurRadius, direction: direction, startOffset: startOffset)
    }
}

private final class VariableBlurNSVisualEffectView: NSVisualEffectView {
    private var configuredDirection: ProgressiveBlurDirection
    private var configuredStartOffset: CGFloat
    private var configuredMaxBlurRadius: CGFloat

    init(maxBlurRadius: CGFloat, direction: ProgressiveBlurDirection, startOffset: CGFloat) {
        self.configuredDirection = direction
        self.configuredStartOffset = startOffset
        self.configuredMaxBlurRadius = maxBlurRadius
        super.init(frame: .zero)
        material = .menu
        blendingMode = .withinWindow
        state = .active
        applyVariableBlur()
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func update(maxBlurRadius: CGFloat, direction: ProgressiveBlurDirection, startOffset: CGFloat) {
        configuredMaxBlurRadius = maxBlurRadius
        configuredDirection = direction
        configuredStartOffset = startOffset
        applyVariableBlur()
    }

    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        if let window, let backdropLayer = subviews.first?.layer {
            backdropLayer.setValue(window.backingScaleFactor, forKey: "scale")
        }
    }

    private func applyVariableBlur() {
        guard let CAFilter = NSClassFromString("CAFilter") as? NSObject.Type,
              let variableBlur = CAFilter.perform(NSSelectorFromString("filterWithType:"), with: "variableBlur")?.takeUnretainedValue() as? NSObject,
              let backdropLayer = subviews.first?.layer else {
            return
        }

        let gradientImage = makeGradientImage(startOffset: configuredStartOffset, direction: configuredDirection)
        variableBlur.setValue(configuredMaxBlurRadius, forKey: "inputRadius")
        variableBlur.setValue(gradientImage, forKey: "inputMaskImage")
        variableBlur.setValue(true, forKey: "inputNormalizeEdges")
        backdropLayer.filters = [variableBlur]

        for subview in subviews.dropFirst() {
            subview.alphaValue = 0
        }
    }

    private func makeGradientImage(
        width: CGFloat = 120,
        height: CGFloat = 120,
        startOffset: CGFloat,
        direction: ProgressiveBlurDirection
    ) -> CGImage {
        let gradient = CIFilter.linearGradient()
        gradient.color0 = CIColor.black
        gradient.color1 = CIColor.clear
        gradient.point0 = CGPoint(x: 0, y: height)
        gradient.point1 = CGPoint(x: 0, y: startOffset * height)

        if direction == .blurredBottomClearTop {
            gradient.point0.y = 0
            gradient.point1.y = height - gradient.point1.y
        }

        let context = CIContext(options: nil)
        return context.createCGImage(
            gradient.outputImage!,
            from: CGRect(x: 0, y: 0, width: width, height: height)
        )!
    }
}

private extension AppTintStyle {
    static var presetCases: [AppTintStyle] {
        [.graphite, .blue, .green, .amber, .rose]
    }

    var color: Color {
        switch self {
        case .graphite: return .white.opacity(0.16)
        case .blue: return Color(red: 0.20, green: 0.52, blue: 1.0)
        case .green: return Color(red: 0.22, green: 0.72, blue: 0.44)
        case .amber: return Color(red: 0.96, green: 0.66, blue: 0.18)
        case .rose: return Color(red: 1.0, green: 0.34, blue: 0.52)
        case .custom: return .clear
        }
    }
}

private extension AppPreferences {
    var tintColor: Color {
        if tintStyle == .custom {
            return customTintColor
        }
        return tintStyle.color
    }

    var customTintColor: Color {
        guard let customTintHex else { return .blue }
        return Color(nsColor: NSColor(hex: customTintHex) ?? .systemBlue)
    }
}

private extension CalendarNewEventTarget {
    var shortTitle: String {
        switch self {
        case .apple: return "Apple"
        case .google: return "Google"
        case .outlook: return "Outlook"
        }
    }
}

private extension Color {
    var hexString: String? {
        #if canImport(AppKit)
        let nsColor = NSColor(self)
        guard let converted = nsColor.usingColorSpace(.deviceRGB) else { return nil }
        let red = Int(round(converted.redComponent * 255))
        let green = Int(round(converted.greenComponent * 255))
        let blue = Int(round(converted.blueComponent * 255))
        return String(format: "#%02X%02X%02X", red, green, blue)
        #else
        return nil
        #endif
    }
}

private extension NSColor {
    convenience init?(hex: String) {
        let cleaned = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        guard cleaned.count == 6, let value = Int(cleaned, radix: 16) else { return nil }
        let red = CGFloat((value >> 16) & 0xFF) / 255
        let green = CGFloat((value >> 8) & 0xFF) / 255
        let blue = CGFloat(value & 0xFF) / 255
        self.init(red: red, green: green, blue: blue, alpha: 1)
    }
}
