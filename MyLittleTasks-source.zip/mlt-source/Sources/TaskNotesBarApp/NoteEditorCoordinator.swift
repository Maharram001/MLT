import AppKit
import SwiftUI

@MainActor
final class NoteEditorCoordinator: ObservableObject {
    private var window: NSWindow?
    private var hostingController: NSHostingController<NoteEditorView>?

    func open(note: NoteItem?, preferences: AppPreferences, onSave: @escaping (_ id: UUID?, _ content: String) -> Void) {
        let host = NSHostingController(
            rootView: NoteEditorView(
                originalID: note?.id,
                initialText: note?.content ?? "",
                preferences: preferences,
                onCancel: { [weak self] in self?.window?.orderOut(nil) },
                onSave: { [weak self] id, content in
                    onSave(id, content)
                    self?.window?.orderOut(nil)
                }
            )
        )
        hostingController = host

        if window == nil {
            let created = NSWindow(
                contentRect: NSRect(x: 0, y: 0, width: 340, height: 342),
                styleMask: [.titled, .resizable, .fullSizeContentView],
                backing: .buffered,
                defer: false
            )
            created.level = .statusBar
            created.center()
            created.isReleasedWhenClosed = false
            created.minSize = NSSize(width: 340, height: 460)
            created.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary]
            created.backgroundColor = .clear
            created.isOpaque = false
            created.hasShadow = false
            created.titleVisibility = .hidden
            created.titlebarAppearsTransparent = true
            created.toolbar = nil
            created.animationBehavior = .utilityWindow
            created.isMovableByWindowBackground = true
            created.appearance = NSAppearance(named: .darkAqua)
            created.standardWindowButton(.closeButton)?.isHidden = true
            created.standardWindowButton(.miniaturizeButton)?.isHidden = true
            created.standardWindowButton(.zoomButton)?.isHidden = true
            window = created
        }

        if let window {
            let contentRect = window.contentRect(forFrameRect: window.frame)
            configureHostedView(host.view, in: contentRect)
            window.contentView = makePanelBackgroundView(frame: contentRect, contentView: host.view)
            host.view.layoutSubtreeIfNeeded()
            let fitting = host.view.fittingSize
            let targetContentSize = NSSize(width: max(340, fitting.width), height: max(460, fitting.height))
            window.setContentSize(targetContentSize)
            if !window.isVisible {
                window.center()
            }
        }
        window?.makeKeyAndOrderFront(nil)
        window?.orderFrontRegardless()
        NSApp.activate(ignoringOtherApps: true)
    }

    private func makePanelBackgroundView(frame: NSRect, contentView: NSView) -> NSView {
        let container = NSView(frame: frame)
        container.autoresizingMask = [.width, .height]
        container.wantsLayer = true
        container.layer?.backgroundColor = NSColor.clear.cgColor
        contentView.frame = container.bounds
        contentView.autoresizingMask = [.width, .height]
        container.addSubview(contentView)
        return container
    }

    private func configureHostedView(_ view: NSView, in frame: NSRect) {
        view.frame = frame
        view.autoresizingMask = [.width, .height]
        view.wantsLayer = true
        view.layer?.backgroundColor = NSColor.clear.cgColor
    }
}

struct NoteEditorView: View {
    let originalID: UUID?
    let preferences: AppPreferences
    let onCancel: () -> Void
    let onSave: (UUID?, String) -> Void

    @State private var text: String

    private var canSave: Bool {
        !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    init(originalID: UUID?, initialText: String, preferences: AppPreferences, onCancel: @escaping () -> Void, onSave: @escaping (UUID?, String) -> Void) {
        self.originalID = originalID
        self.preferences = preferences
        self.onCancel = onCancel
        self.onSave = onSave
        _text = State(initialValue: initialText)
    }

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .fill(.ultraThickMaterial)

            VStack(spacing: 0) {
                HStack(spacing: 8) {
                    Text(originalID == nil ? "New note" : "Edit note")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundStyle(.secondary)

                    Spacer(minLength: 0)
                }
                .padding(.horizontal, 8)
                .padding(.top, 12)
                .padding(.bottom, 6)

                TransparentNoteTextView(text: $text)
                    .padding(.horizontal, 8)
                    .padding(.top, 8)
                    .padding(.bottom, 14)

                HStack(spacing: 8) {
                    Spacer(minLength: 0)

                    Button {
                        onCancel()
                    } label: {
                        Text("Cancel")
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundStyle(.white.opacity(0.92))
                            .frame(minWidth: 74)
                            .frame(height: 30)
                    }
                    .buttonStyle(.plain)
                    .background(
                        RoundedRectangle(cornerRadius: 8, style: .continuous)
                            .fill(.thinMaterial)
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 8, style: .continuous)
                            .strokeBorder(.white.opacity(0.12), lineWidth: 1)
                    )

                    Button {
                        onSave(originalID, text)
                    } label: {
                        Image(systemName: "checkmark")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(canSave ? .black : .white.opacity(0.45))
                            .frame(width: 30, height: 30)
                    }
                    .buttonStyle(.plain)
                    .disabled(!canSave)
                    .background(
                        RoundedRectangle(cornerRadius: 8, style: .continuous)
                            .fill(canSave ? Color.white.opacity(0.95) : Color.white.opacity(0.06))
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 8, style: .continuous)
                            .strokeBorder(canSave ? Color.white.opacity(0.98) : .white.opacity(0.08), lineWidth: 1)
                    )
                    .keyboardShortcut(.defaultAction)
                }
                .padding(.horizontal, 8)
                .padding(.bottom, 8)
            }
        }
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .strokeBorder(.white.opacity(0.08), lineWidth: 1)
        )
        .frame(minWidth: 340, minHeight: 460)
        .fontDesign(.rounded)
        .background(Color.clear)
    }
}

private struct TransparentNoteTextView: NSViewRepresentable {
    @Binding var text: String

    func makeCoordinator() -> Coordinator {
        Coordinator(text: $text)
    }

    func makeNSView(context: Context) -> NSScrollView {
        let scrollView = NSScrollView()
        scrollView.drawsBackground = false
        scrollView.borderType = .noBorder
        scrollView.hasVerticalScroller = true
        scrollView.hasHorizontalScroller = false
        scrollView.autohidesScrollers = true

        let textView = NSTextView()
        textView.isRichText = false
        textView.isAutomaticQuoteSubstitutionEnabled = false
        textView.isAutomaticDashSubstitutionEnabled = false
        textView.isContinuousSpellCheckingEnabled = false
        textView.drawsBackground = false
        textView.backgroundColor = .clear
        textView.insertionPointColor = .labelColor
        textView.textColor = NSColor.labelColor
        textView.font = .systemFont(ofSize: 14, weight: .regular)
        textView.textContainerInset = NSSize(width: 0, height: 4)
        textView.focusRingType = .none
        textView.delegate = context.coordinator
        textView.string = text

        scrollView.documentView = textView
        context.coordinator.textView = textView
        return scrollView
    }

    func updateNSView(_ scrollView: NSScrollView, context: Context) {
        guard let textView = context.coordinator.textView else { return }
        if textView.string != text {
            textView.string = text
        }
    }

    final class Coordinator: NSObject, NSTextViewDelegate {
        @Binding var text: String
        weak var textView: NSTextView?

        init(text: Binding<String>) {
            _text = text
        }

        func textDidChange(_ notification: Notification) {
            guard let textView else { return }
            text = textView.string
        }
    }
}

private extension AppTintStyle {
    var noteTintColor: Color {
        switch self {
        case .graphite: return .white.opacity(0.16)
        case .blue: return Color(red: 0.20, green: 0.52, blue: 1.0)
        case .green: return Color(red: 0.22, green: 0.72, blue: 0.44)
        case .amber: return Color(red: 0.96, green: 0.66, blue: 0.18)
        case .rose: return Color(red: 1.0, green: 0.34, blue: 0.52)
        case .custom: return .blue
        }
    }
}

private extension AppPreferences {
    var tintColor: Color {
        switch tintStyle {
        case .custom:
            guard let customTintHex, let color = NSColor(hex: customTintHex) else { return .blue }
            return Color(nsColor: color)
        default:
            return tintStyle.noteTintColor
        }
    }
}

private extension NSColor {
    convenience init?(hex: String) {
        let cleaned = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        guard cleaned.count == 6, let value = Int(cleaned, radix: 16) else { return nil }
        let red = CGFloat((value >> 16) & 0xFF) / 255
        let green = CGFloat((value >> 8) & 0xFF) / 255
        let blue = CGFloat(value & 0xFF) / 255
        self.init(red: red, green: green, blue: blue, alpha: 1)
    }
}
