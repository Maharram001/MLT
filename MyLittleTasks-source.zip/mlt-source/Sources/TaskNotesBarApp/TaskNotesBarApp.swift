import SwiftUI

@main
struct TaskNotesBarApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate

    @StateObject private var store = AppStore()
    @StateObject private var noteEditor = NoteEditorCoordinator()
    @StateObject private var calendarManager = CalendarManager()

    var body: some Scene {
        let _ = appDelegate.configure(store: store, noteEditor: noteEditor, calendarManager: calendarManager)

        Settings {
            EmptyView()
                .frame(width: 1, height: 1)
        }
    }
}
