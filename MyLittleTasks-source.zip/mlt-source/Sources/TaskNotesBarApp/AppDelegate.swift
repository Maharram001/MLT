import AppKit
import SwiftUI

@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate {
    private var statusItem: NSStatusItem?
    private var panel: MenuPanel?
    private var hostingController: NSHostingController<AnyView>?
    private var store: AppStore?
    private var noteEditor: NoteEditorCoordinator?
    private var calendarManager: CalendarManager?
    private var localClickMonitor: Any?
    private var globalClickMonitor: Any?

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApplication.shared.setActivationPolicy(.accessory)

        let statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        statusItem.button?.target = self
        statusItem.button?.action = #selector(togglePanel(_:))
        statusItem.button?.sendAction(on: [.leftMouseUp])
        self.statusItem = statusItem
        updateMenuBarIcon(systemName: "checklist.checked")

    }

    func configure(store: AppStore, noteEditor: NoteEditorCoordinator, calendarManager: CalendarManager) {
        self.store = store
        self.noteEditor = noteEditor
        self.calendarManager = calendarManager
        store.onPreferencesChanged = { [weak self] preferences in
            self?.apply(preferences: preferences)
        }
        store.onDataChanged = { [weak self] in
            guard let self, let store = self.store else { return }
            self.apply(preferences: store.preferences)
        }
        apply(preferences: store.preferences)
        rebuildContentIfNeeded()
    }

    @objc
    private func togglePanel(_ sender: Any?) {
        if panel == nil {
            createPanel()
        }

        guard let panel, let button = statusItem?.button else { return }

        if panel.isVisible {
            hidePanel()
            return
        }

        position(panel: panel, under: button)
        panel.makeKeyAndOrderFront(nil)
        installOutsideClickMonitors()
        NSApp.activate(ignoringOtherApps: true)
    }

    private func createPanel() {
        let panel = MenuPanel(
            contentRect: NSRect(x: 0, y: 0, width: 360, height: 500),
            styleMask: [.titled, .resizable, .fullSizeContentView],
            backing: .buffered,
            defer: false
        )
        panel.isFloatingPanel = true
        panel.level = .statusBar
        panel.collectionBehavior = [.moveToActiveSpace, .fullScreenAuxiliary]
        panel.titleVisibility = .hidden
        panel.titlebarAppearsTransparent = true
        panel.animationBehavior = .utilityWindow
        panel.standardWindowButton(.closeButton)?.isHidden = true
        panel.standardWindowButton(.miniaturizeButton)?.isHidden = true
        panel.standardWindowButton(.zoomButton)?.isHidden = true
        panel.isMovable = false
        panel.isMovableByWindowBackground = true
        panel.backgroundColor = .clear
        panel.isOpaque = false
        panel.hasShadow = false
        panel.hidesOnDeactivate = false
        panel.becomesKeyOnlyIfNeeded = false
        panel.minSize = NSSize(width: 340, height: 500)

        let hostingController = NSHostingController(rootView: AnyView(EmptyView()))
        let contentRect = panel.contentRect(forFrameRect: panel.frame)
        configureHostedView(hostingController.view, in: contentRect)
        panel.contentView = makePanelBackgroundView(frame: contentRect, contentView: hostingController.view)

        self.panel = panel
        self.hostingController = hostingController
        rebuildContentIfNeeded()
    }

    private func rebuildContentIfNeeded() {
        guard let hostingController, let store, let noteEditor, let calendarManager else { return }

        hostingController.rootView = AnyView(
            MenuBarContentView()
                .environment(\.colorScheme, .dark)
                .environmentObject(store)
                .environmentObject(noteEditor)
                .environmentObject(calendarManager)
        )
    }

    private func position(panel: NSPanel, under button: NSStatusBarButton) {
        guard let buttonWindow = button.window, let screen = buttonWindow.screen ?? NSScreen.main else { return }
        let buttonFrame = button.convert(button.bounds, to: nil)
        let screenFrame = buttonWindow.convertToScreen(buttonFrame)
        let panelSize = panel.frame.size
        let minX = screen.visibleFrame.minX + 8
        let maxX = screen.visibleFrame.maxX - panelSize.width - 8
        let x = min(max(screenFrame.midX - (panelSize.width / 2), minX), maxX)
        let y = screenFrame.minY - panelSize.height - 6
        panel.setFrameOrigin(NSPoint(x: x, y: y))
    }

    private func hidePanel() {
        panel?.orderOut(nil)
        removeOutsideClickMonitors()
    }

    private func installOutsideClickMonitors() {
        removeOutsideClickMonitors()

        localClickMonitor = NSEvent.addLocalMonitorForEvents(matching: [.leftMouseDown, .rightMouseDown]) { [weak self] event in
            self?.handleOutsideClick(event)
            return event
        }

        globalClickMonitor = NSEvent.addGlobalMonitorForEvents(matching: [.leftMouseDown, .rightMouseDown]) { [weak self] event in
            self?.handleOutsideClick(event)
        }
    }

    private func removeOutsideClickMonitors() {
        if let localClickMonitor {
            NSEvent.removeMonitor(localClickMonitor)
            self.localClickMonitor = nil
        }
        if let globalClickMonitor {
            NSEvent.removeMonitor(globalClickMonitor)
            self.globalClickMonitor = nil
        }
    }

    private func handleOutsideClick(_ event: NSEvent) {
        guard let panel, panel.isVisible else { return }

        if let eventWindow = event.window, eventWindow == panel {
            return
        }

        if NSApp.windows.contains(where: { $0.isVisible && $0.className.contains("Popover") }) {
            return
        }

        if let buttonWindow = statusItem?.button?.window, event.window == buttonWindow {
            return
        }

        hidePanel()
    }

    private func apply(preferences: AppPreferences) {
        updateMenuBarIcon(systemName: preferences.menuBarIconSystemName, preferences: preferences)
    }

    private func updateMenuBarIcon(systemName: String, preferences: AppPreferences? = nil) {
        statusItem?.button?.image = MenuBarIconAsset.image(for: systemName)
            ?? NSImage(systemSymbolName: systemName, accessibilityDescription: "MyLittleTasks")
            ?? NSImage(systemSymbolName: "checklist.checked", accessibilityDescription: "MyLittleTasks")
        if let preferences,
           preferences.showPinnedTaskInMenuBar,
           let pinnedID = preferences.pinnedMenuBarTaskID,
           let title = store?.tasks.first(where: { $0.id == pinnedID })?.title {
            statusItem?.button?.title = " " + title.truncatedForMenuBar
        } else {
            statusItem?.button?.title = ""
        }
        statusItem?.button?.toolTip = "MyLittleTasks"
    }

    private func makePanelBackgroundView(frame: NSRect, contentView: NSView) -> NSView {
        if #available(macOS 26, *) {
            let container = NSGlassEffectContainerView(frame: frame)
            container.autoresizingMask = [.width, .height]

            let glassView = NSGlassEffectView(frame: frame)
            glassView.autoresizingMask = [.width, .height]
            glassView.cornerRadius = 20
            container.addSubview(glassView)

            contentView.frame = container.bounds
            contentView.autoresizingMask = [.width, .height]
            container.addSubview(contentView)
            return container
        }

        let effectView = NSVisualEffectView(frame: frame)
        effectView.autoresizingMask = [.width, .height]
        effectView.material = .hudWindow
        effectView.blendingMode = .withinWindow
        effectView.state = .active
        effectView.wantsLayer = true
        effectView.layer?.cornerRadius = 20
        effectView.layer?.masksToBounds = true
        effectView.addSubview(contentView)
        return effectView
    }

    private func configureHostedView(_ view: NSView, in frame: NSRect) {
        view.frame = frame
        view.autoresizingMask = [.width, .height]
        view.wantsLayer = true
        view.layer?.backgroundColor = NSColor.clear.cgColor
    }
}

final class MenuPanel: NSPanel {
    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { true }
}

private extension String {
    var truncatedForMenuBar: String {
        count > 28 ? String(prefix(27)) + "…" : self
    }
}

