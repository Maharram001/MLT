// swift-tools-version: 5.10
import PackageDescription

let package = Package(
    name: "TaskNotesBarApp",
    platforms: [
        .macOS(.v14)
    ],
    products: [
        .executable(name: "TaskNotesBarApp", targets: ["TaskNotesBarApp"])
    ],
    targets: [
        .executableTarget(
            name: "TaskNotesBarApp",
            path: "Sources/TaskNotesBarApp",
            resources: [
                .copy("Resources")
            ]
        )
    ]
)
