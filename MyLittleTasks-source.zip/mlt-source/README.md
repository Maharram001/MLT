# TaskNotesBarApp

Native macOS menu bar app for quick task tracking and note taking.

## Implemented Features

- Menu bar app using `MenuBarExtra` with popup window style.
- Top mode switch (`Tasks` / `Notes`).
- Task quick-add input with Enter to create.
- `#Category` task parsing:
  - Example: `#ACME creating new hero section`
  - Category: `ACME`
  - Task: `creating new hero section`
- Task row actions:
  - Click task text to edit inline.
  - Checkbox to mark complete.
  - Delete button.
- Notes mode:
  - `Take a Note` button opens a floating note window.
  - Clicking an existing note opens the same window prefilled for editing.
  - Save / Cancel actions in note window.
  - Delete button for notes.
- Local persistence in JSON at:
  - `~/Library/Application Support/TaskNotesBarApp/data.json`

## Project Structure

- `Package.swift`
- `Sources/TaskNotesBarApp/TaskNotesBarApp.swift`
- `Sources/TaskNotesBarApp/MenuBarContentView.swift`
- `Sources/TaskNotesBarApp/AppStore.swift`
- `Sources/TaskNotesBarApp/NoteEditorCoordinator.swift`
- `Sources/TaskNotesBarApp/Models.swift`
- `Sources/TaskNotesBarApp/AppDelegate.swift`

## Run

1. Open the folder in Xcode and run the `TaskNotesBarApp` executable target.
2. Or build/run from terminal:
   - `swift run TaskNotesBarApp`

## Notes

- The app currently targets `macOS 14+`.
- UI is native SwiftUI/AppKit and stays minimal to match macOS system styling.
